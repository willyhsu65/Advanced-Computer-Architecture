#!/usr/bin/env python3
"""Install the exact target toolchain and rebuild the bundled custom Spike."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import platform
import shutil
import shlex
import subprocess
import sys
import tarfile
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
TOOLCHAIN = "xpack-riscv-none-embed-gcc-10.2.0-1.2"
URL = ("https://github.com/xpack-dev-tools/riscv-none-embed-gcc-xpack/releases/"
       "download/v10.2.0-1.2/" + TOOLCHAIN + "-linux-x64.tar.gz")
SHA256 = "d72bdcd1eee41dc5a208a8a03976b70d014510deb5890c9e8738e804ba23f985"


def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--jobs", type=int, default=4)
    p.add_argument("--toolchain-archive", type=Path)
    a = p.parse_args()
    if sys.version_info < (3, 10):
        p.error("Python >= 3.10 is required")
    if platform.system() != "Linux" or platform.machine() not in ("x86_64", "amd64"):
        p.error("Use Linux x86_64, WSL2 x86_64, or the linux/amd64 Docker image")
    if a.jobs < 1:
        p.error("--jobs must be positive")
    if any(c.isspace() for c in str(ROOT)):
        p.error('Use a checkout path without whitespace (required by the supplied Makefiles)')
    for command in ("make", "gcc", "g++", "dtc", "ar"):
        if not shutil.which(command):
            p.error(command + " missing; run scripts/install_host_deps.sh or use Docker")
    tools = ROOT / "tools"
    tools.mkdir(exist_ok=True)
    target = tools / TOOLCHAIN
    archive = a.toolchain_archive or tools / (TOOLCHAIN + "-linux-x64.tar.gz")
    prefix = target / "bin/riscv-none-embed-"
    if not target.is_dir() or not (tools / ".toolchain-verified.json").is_file():
        if not archive.is_file():
            print("Downloading pinned RISC-V GCC (about 546 MiB)", flush=True)
            partial = archive.with_suffix(archive.suffix + ".part")
            try:
                with urllib.request.urlopen(URL, timeout=120) as response, partial.open("wb") as f:
                    shutil.copyfileobj(response, f)
                partial.replace(archive)
            finally:
                partial.unlink(missing_ok=True)
        if digest(archive) != SHA256:
            raise SystemExit("Toolchain archive checksum mismatch: " + str(archive))
        print("Verified archive SHA256; extracting toolchain", flush=True)
        with tarfile.open(archive, "r:gz") as tf:
            for member in tf.getmembers():
                if not (tools / member.name).resolve().is_relative_to(tools.resolve()):
                    raise SystemExit("Invalid archive member")
            tf.extractall(tools)
        binaries = {name: digest(Path(str(prefix) + name)) for name in ("gcc", "g++", "objdump")}
        (tools / ".toolchain-verified.json").write_text(json.dumps(
            dict(archive_sha256=SHA256, binaries=binaries), indent=2) + "\n")
    saved = json.loads((tools / ".toolchain-verified.json").read_text())
    if saved["archive_sha256"] != SHA256:
        raise SystemExit("Unexpected toolchain verification stamp")
    for name, sha in saved["binaries"].items():
        if digest(Path(str(prefix) + name)) != sha:
            raise SystemExit("Installed toolchain changed: " + name)
    subprocess.run([str(prefix) + "g++", "--version"], check=True)
    venv = tools / "model-env"
    if not (venv / "bin/python").is_file():
        subprocess.run([sys.executable, "-m", "venv", "--without-pip", str(venv)], check=True)
    # These inference/measurement entry points use only Python's standard library.
    source = tools / "riscv-isa-sim"
    if not source.exists():
        shutil.copytree(ROOT / "spike/source", source)
    expected = ROOT / "spike/source/riscv/insns/qrequant8_math.inc"
    if (source / "riscv/insns/qrequant8_math.inc").read_bytes() != expected.read_bytes():
        raise SystemExit("Existing tools/riscv-isa-sim differs from bundled source")
    build = source / "build-gcc12"
    build.mkdir(exist_ok=True)
    wrapper = ROOT / "scripts/host_cxx.sh"
    wrapper.chmod(0o755)
    cxx = "bash " + shlex.quote(str(wrapper))
    env = dict(os.environ, CXX=cxx, CC=os.environ.get("CC", "gcc"))
    env.pop("LD_PRELOAD", None)
    if not (build / "Makefile").exists():
        subprocess.run(["bash", str(source / "configure"), "--enable-histogram",
                        "--prefix=" + str(tools / "spike-install")],
                       cwd=build, env=env, check=True)
    print("Building custom Spike with histogram support", flush=True)
    subprocess.run(["make", "-j" + str(a.jobs), "CXX=" + cxx, "spike"],
                   cwd=build, env=env, check=True)
    result = dict(toolchain_url=URL, toolchain_archive_sha256=SHA256,
                  spike_sha256=digest(build / "spike"), host=platform.platform(),
                  python=sys.version, host_cxx=os.environ.get("SPIKE_HOST_CXX", "g++"))
    (tools / "bootstrap.json").write_text(json.dumps(result, indent=2) + "\n")
    print("BOOTSTRAP PASS", flush=True)


if __name__ == "__main__":
    main()
