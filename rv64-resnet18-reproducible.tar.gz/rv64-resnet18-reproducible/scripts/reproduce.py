#!/usr/bin/env python3
"""Build, test and reproduce the frozen workload using Python stdlib only."""
from pathlib import Path
import argparse
import csv
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
VERSIONS = ("B0", "B1_block8_ptr", "X1", "X2")
PREFIX = str(ROOT / "tools/xpack-riscv-none-embed-gcc-10.2.0-1.2/bin/riscv-none-embed-")
SPIKE = ROOT / "tools/riscv-isa-sim/build-gcc12/spike"
EXPECTED = json.loads((ROOT / "repro/expected.json").read_text())

def require(condition, message):
    if not condition:
        raise RuntimeError(message)

def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for b in iter(lambda: f.read(1024 * 1024), b""):
            h.update(b)
    return h.hexdigest()

def write_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2) + "\n")

def environment():
    env = dict(os.environ)
    for n in ("LD_PRELOAD", "LD_LIBRARY_PATH", "PYTHONPATH", "PYTHONHOME", "CPATH",
              "CPLUS_INCLUDE_PATH", "LIBRARY_PATH", "GCC_EXEC_PREFIX", "COMPILER_PATH",
              "CFLAGS", "CXXFLAGS", "CPPFLAGS", "LDFLAGS"):
        env.pop(n, None)
    env.update(RISCV_PREFIX=PREFIX, SPIKE=str(SPIKE), PYTHON=sys.executable,
               ACA_PROJECT=str(ROOT), LC_ALL="C", TZ="UTC", PYTHONUTF8="1")
    return env

def run(args, log, cwd=ROOT, timeout=14400):
    log.parent.mkdir(parents=True, exist_ok=True)
    print("RUN:", " ".join(map(str, args)), flush=True)
    with log.open("w") as f:
        r = subprocess.run(list(map(str, args)), cwd=cwd, env=environment(),
                           stdout=f, stderr=subprocess.STDOUT, timeout=timeout)
    text = log.read_text(errors="replace")
    require(r.returncode == 0, f"Exit {r.returncode}: {log}\n" + "\n".join(text.splitlines()[-30:]))
    return text

def make(version, targets, log, jobs):
    return run(["make", "MODE=frozen", f"-j{jobs}", "RISCV_PREFIX=" + PREFIX,
                "SPIKE=" + str(SPIKE), "PYTHON=" + sys.executable, "CXX=g++", *targets],
               log, ROOT / "workloads" / version)

def build(version, jobs, nodes=False):
    targets = ["-f", "scripts/node_profile.mk", "node-profile-elf"] if nodes else ["spike"]
    make(version, targets, ROOT / "results" / version / ("build-nodes.log" if nodes else "build.log"), jobs)
    if not nodes:
        out = ROOT / "results" / version
        elf = ROOT / "workloads" / version / "build/rv64-frozen/resnet18_tflm.elf"
        args = [sys.executable, ROOT/'scripts/audit_target.py', PREFIX, elf, '--json', out/'audit.json']
        if version == 'B0': args += ['--allow-linked-soft-float']
        run(args, out/'audit.log')

def verification(jobs):
    out = ROOT / "results/verification"
    out.mkdir(parents=True, exist_ok=True)
    (out / "PASS.json").unlink(missing_ok=True)
    records = []
    for v in ("X1", "X2"):
        make(v, ["-f", "scripts/instruction_tests.mk", "qmac8-test-elf"], out / f"{v}-qmac8-build.log", jobs)
        elf = ROOT / "workloads" / v / "build/rv64-frozen/qmac8_test.elf"
        text = run([SPIKE, "--isa=RV64IMC", "-m128", elf], out / f"{v}-qmac8.log", timeout=120)
        require("QMAC8 TEST PASS: 31537 checks" in text, "qmac8 PASS missing")
        records.append(dict(version=v, test="qmac8", checks=31537, elf_sha256=sha(elf)))
    text = make("X2", ["requant-host-test"], out / "X2-requant-host.log", jobs)
    require("QREQUANT8 TEST PASS: 100007 checks" in text and
            "REQUANT BENCH PASS: 4096 outputs" in text, "Host requant PASS missing")
    make("X2", ["requant-spike-test"], out / "X2-requant-build.log", jobs)
    workload = ROOT / "workloads/X2"
    text = run([sys.executable, "scripts/measure_requant.py"], out / "X2-requant.log", workload, 300)
    require("QREQUANT8 TEST PASS: 100007 checks" in text, "Spike requant PASS missing")
    data = json.loads((workload / "results/requant/metrics.json").read_text())
    for key in ("software_retired", "custom_retired", "outputs"):
        require(data[key] == EXPECTED["requant"][key], "Requant mismatch: " + key)
    shutil.copy2(workload / "results/requant/metrics.json", out / "requant-metrics.json")
    records.append(dict(version="X2", test="qrequant8", checks=100007,
                        elf_sha256=sha(workload / "build/qrequant8-test.elf")))
    write_json(out / "PASS.json", dict(status="PASS", tests=records, spike_sha256=sha(SPIKE)))
    print("ALL INSTRUCTION TESTS PASS", flush=True)

def inference(v, jobs, timeout):
    build(v, jobs)
    elf = ROOT / "workloads" / v / "build/rv64-frozen/resnet18_tflm.elf"
    out = ROOT / "results" / v / "inference"
    out.mkdir(parents=True, exist_ok=True)
    (out / "measurements.json").unlink(missing_ok=True)
    symbols = {}
    listing = subprocess.check_output([PREFIX + "nm", "-n", str(elf)], text=True, env=environment())
    for line in listing.splitlines():
        f = line.split()
        if len(f) == 3 and f[2] in ("inference_begin", "inference_end"):
            require(f[2] not in symbols, "Duplicate inference marker")
            symbols[f[2]] = int(f[0], 16)
    require(len(symbols) == 2 and len(set(symbols.values())) == 2, "Missing inference markers")
    commands = out / "debug.cmd"
    commands.write_text("".join(f"until pc 0 {symbols[n]:x}\npc 0\nreg 0 minstret\n"
        for n in ("inference_begin", "inference_end")) + "rs\n")
    args = [str(SPIKE), "--isa=RV64IMC", "-m128", "-d", "--debug-cmd=" + str(commands), str(elf)]
    print("MEASURING:", v, "Invoke (no histogram)", flush=True)
    with (out / "run.log").open("w") as stdout, (out / "debug.log").open("w") as stderr:
        r = subprocess.run(args, env=environment(), stdout=stdout, stderr=stderr, timeout=timeout)
    require(r.returncode == 0, "Inference failed: " + str(out))
    require("TFLM FULL INFERENCE: PASS" in (out / "run.log").read_text(), "Model output failed")
    values = re.findall(r"(?m)^\s*(?::\s*)?(0x[0-9a-fA-F]{1,16})[ \t]*$", (out / "debug.log").read_text())
    require(len(values) == 4, "Unexpected inference counter log")
    begin, start, end, stop = map(lambda x: int(x, 16), values)
    require(begin == symbols["inference_begin"] and end == symbols["inference_end"] and stop > start,
            "Invalid counter PCs/range")
    require(stop-start == EXPECTED["versions"][v]["invoke_retired"], f"{v} counter mismatch: {stop-start}")
    write_json(out / "measurements.json", dict(status="PASS", elf_sha256=sha(elf),
        retired={"invoke": dict(start=start, end=stop)}, invoke_retired=stop-start))
    print(f"{v} INFERENCE PASS: {stop-start:,}", flush=True)

def nodes(v, jobs, timeout):
    (ROOT/'results'/v/'nodes/PASS.json').unlink(missing_ok=True)
    build(v, jobs, nodes=True)
    workload = ROOT / "workloads" / v
    run([sys.executable, "scripts/run_nodes.py"], ROOT / "results" / v / "nodes.log", workload, timeout)
    source = workload / "results/node-profile"
    data = json.loads((source / "metadata.json").read_text())
    expected = EXPECTED["versions"][v]
    require(data["node_count"] == expected["node_count"], v + " node count mismatch")
    require(data["invoke_retired"] == expected["node_invoke_retired"], v + " node Invoke mismatch")
    def rows(path):
        with path.open() as f:
            return list(csv.DictReader(f))
    require(rows(source / "nodes.csv") == rows(ROOT / "reference-results" / v / "results/node-profile/nodes.csv"),
            v + " individual node counters differ")
    dest = ROOT / "results" / v / "nodes"
    dest.mkdir(parents=True, exist_ok=True)
    for name in ("nodes.csv", "operators.csv", "metadata.json", "summary.md", "run.log"):
        shutil.copy2(source / name, dest / name)
    write_json(dest / "PASS.json", dict(status="PASS", node_count=data["node_count"], invoke_retired=data["invoke_retired"]))
    print(v + " NODE PROFILE PASS (all rows match)", flush=True)

def profile(v, jobs, timeout):
    (ROOT/'results'/v/'profile/PASS.json').unlink(missing_ok=True)
    build(v, jobs)
    workload = ROOT / "workloads" / v
    run(["make", "MODE=frozen", "profile", "RISCV_PREFIX=" + PREFIX, "SPIKE=" + str(SPIKE),
         "PYTHON=" + sys.executable, "CXX=g++"], ROOT / "results" / v / "profile.log", workload, timeout)
    check_profile(v)

def check_profile(v, saved_report=None):
    """Validate saved report data; this function does not execute inference."""
    (ROOT/'results'/v/'profile/PASS.json').unlink(missing_ok=True)
    workload = ROOT / 'workloads' / v
    source = Path(saved_report).resolve() if saved_report else workload / "report"
    d = json.loads((source / "metrics.json").read_text())
    require(d['elf_sha256'] == sha(source/'program.elf') ==
            sha(workload/'build/rv64-frozen/resnet18_tflm.elf'), 'Report ELF mismatch')
    e = EXPECTED["versions"][v]
    require("TFLM FULL INFERENCE: PASS" in (source / "run.log").read_text(), "Profile model failed")
    require(d["retired_instruction_count"]["invoke"] == e["invoke_retired"], v + " Invoke mismatch")
    require(d["histogram_dynamic_count"] == e["histogram_dynamic_count"], v + " histogram mismatch")
    require(d["code_bytes"] == e["code_bytes"], v + " code size mismatch")
    reference = json.loads((ROOT / "reference-results" / v / "report/metrics.json").read_text())
    require(d["instruction_mix"] == reference["instruction_mix"], v + " instruction mix mismatch")
    sys.path.insert(0, str(ROOT/'scripts'))
    from audit_target import fp_name
    pcs, current = set(), ''
    for line in (source/'disassembly.txt').read_text().splitlines():
        header = re.match(r'^\s*[0-9a-fA-F]+\s+<(.+)>:\s*$', line)
        if header: current = header[1]
        pc = re.match(r'^\s*([0-9a-fA-F]+):', line)
        if pc and fp_name(current): pcs.add(int(pc[1],16))
    dynamic_fp = 0
    for line in (source/'pc-histogram.txt').read_text().splitlines():
        item = re.fullmatch(r'\s*((?:0x)?[0-9a-fA-F]+)\s+([0-9]+)\s*',line)
        if item and int(item[1],16) in pcs: dynamic_fp += int(item[2])
    require(dynamic_fp == 0, v+' executed software floating-point helpers')
    write_json(source/'dynamic-fp-audit.json',dict(status='PASS',scope='whole_program',
        software_fp_helper_dynamic_instructions=dynamic_fp, mapped_helper_instruction_pcs=len(pcs)))
    dest = ROOT / "results" / v / "profile"
    if source.resolve() != dest.resolve():
        if dest.exists():
            shutil.rmtree(dest)
        shutil.copytree(source, dest)
    write_json(dest / "PASS.json", dict(status="PASS", invoke_retired=e["invoke_retired"],
                                       histogram_dynamic_count=d["histogram_dynamic_count"]))
    print(v + " FULL PROFILE PASS", flush=True)

def expected_table(versions):
    lines = ["| Version | Invoke retired | Node Invoke retired | Full histogram |", "|---|---:|---:|---:|"]
    for v in versions:
        e = EXPECTED["versions"][v]
        lines.append(f"| {v} | {e['invoke_retired']:,} | {e['node_invoke_retired']:,} | {e['histogram_dynamic_count']:,} |")
    return "\n".join(lines) + "\n"

def integrity():
    manifest = json.loads((ROOT / "repro/source-manifest.json").read_text())
    for name, expected in manifest.items():
        require((ROOT/name).is_file() and sha(ROOT/name) == expected, "Source/data changed: " + name)
    print(f"SOURCE INTEGRITY PASS: {len(manifest)} files", flush=True)

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("action", choices=("integrity", "build", "verify", "inference", "nodes", "profile", "check-profile", "all", "expected"))
    p.add_argument("--versions", nargs="+", choices=VERSIONS, default=list(VERSIONS))
    p.add_argument("--jobs", type=int, default=4)
    p.add_argument("--timeout", type=int, default=14400, help="seconds per model run")
    p.add_argument('--saved-report', type=Path, help='check-profile only: validate an existing report without running inference')
    a = p.parse_args()
    require(a.jobs > 0 and a.timeout > 0, "jobs/timeout must be positive")
    if a.saved_report and (a.action != 'check-profile' or len(a.versions) != 1):
        p.error('--saved-report requires check-profile and exactly one --versions value')
    if a.action == "expected":
        print(expected_table(a.versions)); return
    if a.action != 'integrity':
        (ROOT/'results/ALL_PASS.json').unlink(missing_ok=True)
    integrity()
    if a.action == "integrity": return
    require(SPIKE.is_file(), "Run python3 scripts/bootstrap.py first")
    if a.action in ("verify", "all"): verification(a.jobs)
    for v in a.versions:
        if a.action == "build": build(v, a.jobs)
        elif a.action == "inference": inference(v, a.jobs, a.timeout)
        elif a.action in ("profile", "all"): profile(v, a.jobs, a.timeout)
        elif a.action == 'check-profile': check_profile(v, a.saved_report)
        if a.action in ("nodes", "all"): nodes(v, a.jobs, a.timeout)
    if a.action == "all":
        (ROOT / "results/comparison.md").write_text(expected_table(a.versions))
        write_json(ROOT / "results/ALL_PASS.json", dict(status="PASS", versions=a.versions,
            scopes=["instruction_tests", "full_profile", "nodes"], spike_sha256=sha(SPIKE)))
        print("ALL REPRODUCTION CHECKS PASS", flush=True)

if __name__ == "__main__":
    try:
        main()
    except (RuntimeError, OSError, ValueError, subprocess.SubprocessError) as error:
        raise SystemExit("REPRODUCTION FAILED: " + str(error))
