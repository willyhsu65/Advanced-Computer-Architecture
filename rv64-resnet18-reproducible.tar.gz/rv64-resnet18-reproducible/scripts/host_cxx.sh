#!/usr/bin/env bash
set -euo pipefail
args=()
for arg in "$@"; do
    case "$arg" in
        -Werror|-Werror=*) args+=("-Wno-error${arg#-Werror}") ;;
        *) args+=("$arg") ;;
    esac
done
exec "${SPIKE_HOST_CXX:-g++}" "${args[@]}"
