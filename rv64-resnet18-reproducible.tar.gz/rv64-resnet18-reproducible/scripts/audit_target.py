#!/usr/bin/env python3
"""Separate hardware ISA violations from linked, possibly unexecuted FP helpers."""
from pathlib import Path
import argparse
import json
import re
import subprocess

HELPERS = re.compile(r'\b__(?:(?:add|sub|mul|div|neg)(?:sf|df|tf)\d|(?:eq|ne|ge|gt|le|lt|unord|cmp)(?:sf|df|tf)\d|(?:fix|float|extend|trunc)\w+|(?:un)?pack_[df])\w*\b')
MATH = re.compile(r'\b(?:frexp|ldexp|scalbn|exp|log|pow|sqrt|round|floor|ceil|sin|cos|tan|fmod|fma)(?:f|l)?$')

def fp_name(name):
    return bool(HELPERS.search(name) or MATH.search(name) or
                re.search(r'(?:_dtoa|_ftoa|_etoa|__.*(?:sf|df)3)', name))

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('prefix')
    p.add_argument('elf', type=Path)
    p.add_argument('--allow-linked-soft-float', action='store_true')
    p.add_argument('--json', type=Path, required=True)
    a = p.parse_args()
    def tool(name, *args):
        return subprocess.check_output([a.prefix+name, *args, str(a.elf)], text=True)
    attrs = tool('readelf', '-A')
    arch = re.search(r'Tag_RISCV_arch:\s*"([^"]+)"', attrs).group(1)
    assert arch.split('_')[0].startswith('rv64i'), arch
    assert all(re.fullmatch(r'(m|c|zmmul|zca)\d+p\d+', n) for n in arch.split('_')[1:]), arch
    disassembly = tool('objdump', '-d', '--no-show-raw-insn')
    bad = []
    for line in disassembly.splitlines():
        m = re.match(r'^\s*[0-9a-f]+:\s+(\S+)', line)
        if not m: continue
        op = m[1]
        if ((op.startswith('f') and not op.startswith('fence')) or op.startswith('c.f') or
            op.startswith('v') or op.startswith(('amo', 'lr.', 'sc.'))):
            bad.append(line)
    linked = [line for line in tool('nm', '-C').splitlines() if fp_name(line)]
    result = dict(arch=arch, forbidden_hardware_instructions=bad, linked_fp_symbols=linked,
                  static_zero_float=not bad and not linked,
                  dynamic_fp_audit_required=bool(linked))
    a.json.parent.mkdir(parents=True, exist_ok=True)
    a.json.write_text(json.dumps(result, indent=2)+'\n')
    assert not bad, 'Forbidden hardware instructions: '+str(bad)
    assert not linked or a.allow_linked_soft_float, 'Software FP helpers linked; see '+str(a.json)
    print('RV64IMC HARDWARE ISA AUDIT: PASS')
    print('Linked software FP symbols:', len(linked))
    print('STATIC ZERO-FLOAT: '+('PASS' if not linked else 'NOT SATISFIED; dynamic audit required'))

if __name__ == '__main__': main()
