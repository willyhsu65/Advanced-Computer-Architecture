#!/usr/bin/env bash
set -euo pipefail
if [[ "$(id -u)" -eq 0 ]]; then
    elevated=()
else
    elevated=(sudo)
fi
"${elevated[@]}" apt-get update
"${elevated[@]}" apt-get install -y --no-install-recommends \
    build-essential python3 python3-venv ca-certificates curl git \
    device-tree-compiler libboost-regex-dev libboost-system-dev
