require_rv64;
const uint64_t x = RS1, w = RS2;
uint32_t acc = uint32_t(READ_REG(insn.rd()));
for (unsigned i = 0; i < 8; ++i) {
  int32_t a = (x >> (8 * i)) & 255;
  int32_t b = (w >> (8 * i)) & 255;
  if (a >= 128) a -= 256;
  if (b >= 128) b -= 256;
  acc += uint32_t(a * b);
}
WRITE_RD(sext32(acc));
