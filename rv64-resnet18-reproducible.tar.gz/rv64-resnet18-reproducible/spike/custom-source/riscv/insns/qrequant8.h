require_rv64;
#include "qrequant8_math.inc"
const uint64_t acc = READ_REG(insn.rd());
const uint64_t multiplier = RS1, control = RS2;
require(X2RequantMath::Valid(multiplier, control));
WRITE_RD(reg_t(X2RequantMath::Execute(acc, multiplier, control)));
