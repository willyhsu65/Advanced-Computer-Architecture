# Evaluated configurations

| Version | Configuration |
|---|---|
| B0 | Baseline RV64IMC workload |
| B1_block8_ptr | Software optimization: block8 and pointer increment |
| X1 | Packed INT8 MAC instruction added |
| X2 | X1 plus fused requantization instruction |

Conv+Add operator fusion is not part of these evaluated configurations.

Fused requantization combines scaling, rounding, shifting,
zero-point addition and saturation into one instruction.
It is distinct from Conv+Add operator fusion.

Formal inference measurements and instrumented per-node measurements
must be reported separately.
