# Upload this project to GitHub

Create an empty repository on GitHub. Then run the commands below from the
extracted project root (the directory containing REPRODUCE.md and workloads/).
Replace the author and repository URL with your own values.

```bash
git init
git config user.name "YOUR NAME"
git config user.email "YOUR EMAIL"
git add .
git status --short
git commit -m "Add reproducible RV64IMC ResNet-18 workload and custom ISA"
git branch -M main
git remote add origin https://github.com/YOUR_ACCOUNT/YOUR_REPOSITORY.git
git push -u origin main
```

These commands do not require the newer `git -C` or `git init -b` options.
For HTTPS authentication, use GitHub's supported token/credential flow rather
than an account password. Never put an access token in the remote URL or commit it.

tools/, generated build directories and fresh results are ignored. The model,
input, golden output, source dependencies, original reference results, expected
counters, reproducibility scripts and workflow configuration are committed.

After pushing, check the Clean environment reproduction workflow. The normal
workflow checks short tests plus full X2 node inference. Use its manual full
option to run all four full histograms and per-node profiles.

The original supplied evidence is reference-results/. New evidence is results/
and is available from the workflow artifacts. GitHub Actions is not considered
passed merely because the workflow YAML exists; wait for its actual green run.
