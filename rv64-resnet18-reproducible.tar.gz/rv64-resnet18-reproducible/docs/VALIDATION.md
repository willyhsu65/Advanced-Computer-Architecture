# Validation performed on the prepared source package

See `docs/validation/summary.json` and the accompanying raw logs/JSON/CSV files.

The Linux x86_64 validation downloaded the official GCC 10.2.0-1.2 archive,
verified its published SHA256, rebuilt custom Spike from the bundled source,
and compiled the supplied target sources without using uploaded build objects.
All four formal model ELFs exactly match the original recorded ELF SHA256s.

The following actual executions passed:

- X1 qmac8: 31537 checks.
- X2 qmac8: 31537 checks.
- X2 requantization: 100007 checks, plus 4096 matching benchmark outputs.
- Requantization microbenchmark: software 212708, custom 53252 retired instructions.
- All four complete model outputs: zero mismatches.
- All four per-node profiles: 37 nodes each; every CSV row matches the original.
- All four full histograms: Invoke counts, histogram totals, instruction mix and code size match.
- All four dynamic software-FP-helper audits: zero executed mapped helper instructions.

B1 was additionally rebuilt/profiled in an independent relocated source directory.
The relocation validation copy initially omitted its reference-results/report
directory; that validation-copy omission was corrected and the already executed
raw report was checked without rerunning or synthesizing its counters.

The plain standard-library Python environment was also used for the short tests;
TensorFlow was not installed into that environment.

Five host-side regression tests check reference provenance, changed-source
rejection, subprocess failure rejection, saved-report/ELF identity and FP-helper
classification. These supplement, rather than replace, the Spike executions.

B0 has linked but unexecuted software FP helpers from unused operator
registrations. Its strict static zero-float claim is **not** satisfied; the
dynamic result and the distinction are preserved in the audit evidence.

Docker/Podman was unavailable in the validation environment, so the supplied
Docker recipe has not been executed locally. The native workflow was exercised;
the actual GitHub Actions runs, including the optional Docker check, require
pushing the repository and must be observed separately.
