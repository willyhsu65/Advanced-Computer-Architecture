# Excluded legacy scripts

The following unused installation scripts are intentionally excluded:

- workloads/B1_block8_ptr/scripts/install_conv_add_fusion.py
- workloads/X1/scripts/install_conv_add_fusion.py
- workloads/X2/scripts/install_conv_add_fusion.py

These files have identical SHA256 hashes and contain damaged source text.
Conv+Add fusion is not included in the evaluated configurations.
Their presence in the development folders does not indicate activation.

The original development files are preserved.
See excluded-scripts.csv for the recorded validation errors.
