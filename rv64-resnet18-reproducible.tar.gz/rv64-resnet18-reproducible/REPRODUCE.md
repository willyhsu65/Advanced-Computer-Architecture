# Clean-environment reproduction

The supported host is Linux x86_64 with Python >= 3.10 and a C++20 host compiler
(Ubuntu 24.04 is recommended). Windows users can use WSL2. A pinned Linux/amd64
Dockerfile is also supplied. No TensorFlow installation, quantization, retraining,
or model regeneration is needed for the frozen benchmark.
Use a checkout path without whitespace, as required by the supplied Makefiles.

## Native Linux

From the repository root:

```bash
bash scripts/install_host_deps.sh
python3 scripts/bootstrap.py --jobs 4
python3 -m unittest discover -s tests -v
python3 scripts/reproduce.py verify --jobs 4
python3 scripts/reproduce.py all --jobs 4
```

The dependency installer uses apt and requires root/sudo. If these dependencies
are already installed, the bootstrap, build and benchmark steps require no root.
The target toolchain download is approximately 546 MiB. It is downloaded into
`tools/` and checked against a fixed SHA256 before extraction. The first Spike
build can take several minutes. Full histogram runs can take much longer than
ordinary inference; allow up to four hours per version or override `--timeout`.

Success is reported as `ALL REPRODUCTION CHECKS PASS`, with machine-readable
evidence in `results/ALL_PASS.json`. Any wrong output, changed reference counter,
failed command or source-integrity mismatch stops the run with a nonzero status.

## Individual steps

```bash
# Fast full-model correctness + per-node retired counts, checked row by row:
python3 scripts/reproduce.py nodes --versions B0 B1_block8_ptr X1 X2

# Formal Invoke counters without collecting an instruction histogram:
python3 scripts/reproduce.py inference --versions X2

# Full-program histogram, instruction mix, code size and Invoke counters:
python3 scripts/reproduce.py profile --versions X2

# Show the supplied reference numbers without running a benchmark:
python3 scripts/reproduce.py expected

# Re-check an already saved report without executing inference again:
python3 scripts/reproduce.py check-profile --versions X2 --saved-report results/X2/profile
```

`verify` runs qmac8 in X1 and X2, the native requantization comparison, and the
requantization test on the rebuilt Spike. Expected messages are
`QMAC8 TEST PASS: 31537 checks`, `QREQUANT8 TEST PASS: 100007 checks`, and
`REQUANT BENCH PASS: 4096 outputs`. It also verifies the recorded microbenchmark
counters (software 212708, custom 53252 instructions for 4096 outputs).

The top-level `bash scripts/run_verification.sh` is an equivalent short-test entry.

## Docker

```bash
docker build --platform linux/amd64 --build-arg JOBS=4 -t rv64-resnet18 .
docker run --rm rv64-resnet18 verify --jobs 4
mkdir -p results
docker run --rm -v "$(pwd)/results:/project/results" rv64-resnet18 all --jobs 4
```

The image pins an Ubuntu manifest digest and Ubuntu package snapshot. The pinned
target compiler and bundled Spike sources are the same as the native route.
Docker itself is an alternative host setup; the Docker build is not needed when
the native host dependencies are available.

## Measurement definitions

| Version | Formal Invoke retired | Instrumented Node Invoke retired | Whole-program histogram |
|---|---:|---:|---:|
| B0 | 22162997184 | 22162999146 | 22171572199 |
| B1_block8_ptr | 9723910788 | 9723912750 | 9732485802 |
| X1 | 4451759640 | 4451761602 | 4460339654 |
| X2 | 4484518827 | 4484520789 | 4493103841 |

These are distinct scopes. Node profiling has small measurement overhead, and
instruction contribution is not time/cycle contribution. The fresh runs are
compared with `repro/expected.json` and `reference-results/`; the old results are
never used as substitutes for fresh benchmark output. No cycle speedup is claimed.

X2 has a better requantization microbenchmark but a larger whole-model instruction
count than X1 in the supplied implementation. Reproduction preserves this result;
it does not change kernels to obtain a more favorable number.

## Floating-point audit scope

All target builds use RV64IMC/LP64. B1_block8_ptr, X1 and X2 are required to pass
the static audit for forbidden hardware instructions and linked software FP helpers.

B0 deliberately registers unused operators, including Softmax. Their function
pointers keep software FP helpers linked in the original ELF. B0 therefore does
**not** satisfy a whole-ELF static zero-float claim. This is not hidden or changed:
its audit JSON lists these symbols, and its full histogram must additionally prove
zero executed instructions in the mapped software FP helpers. The formal `all`
path enforces this dynamic check. A `nodes` run alone does not establish that fact.

## Repository inputs and outputs

- `workloads/`: exact model, input, golden output, frozen parameters, kernels and runtime sources.
- `spike/source/`: complete bundled custom Spike source; do not reapply the historical patch to it.
- `spike/changes.patch`, `new-files/`, `custom-source/`: historical review aids.
- `repro/source-manifest.json`: SHA256 for the source/data used by reproduction.
- `reference-results/`: immutable supplied measurements and original verification evidence.
- `results/`: new runs, ignored by Git.
- `development-history/`: preserved old installers/backups; not part of the build workflow.
- `docs/environment/`: original machine's provenance; not a required Python environment.

`MODE=export` and the development-history scripts are not required or automatically
executed. The benchmark uses the supplied quantized model and golden output.

## GitHub Actions

Push/PR checks rebuild Spike, run the short tests and compare the complete X2 node
profile. Under Actions -> Clean environment reproduction -> Run workflow, select
`full` to also run all four complete histograms and node profiles. Each matrix job
uploads its fresh `results/` as a downloadable artifact. The project must be pushed
before these workflows can run; no remote workflow execution is assumed locally.
The manual `container` option additionally builds and tests the pinned Docker image.
