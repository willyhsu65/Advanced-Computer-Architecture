from pathlib import Path
import shutil
import sys

block = int(sys.argv[1])
assert block in (1, 2, 4, 8, 16), 'Choose 1, 2, 4, 8 or 16.'
root = Path.cwd().resolve()
assert root.name == 'B1', 'Run from the original B1 folder.'
header = root / 'src/tensorflow/lite/micro/kernels/internal/reference/integer_ops/conv.h'
assert '"conv_block4.inc"' in header.read_text(), 'Kernel include not found.'
code = (root / 'src/conv_block4.inc').read_text()

def replace_once(old, new):
    global code
    assert code.count(old) == 1, 'Unexpected kernel: ' + old
    code = code.replace(old, new, 1)

def replace_region(first, last, new):
    global code
    assert code.count(first) == code.count(last) == 1
    begin = code.index(first)
    end = code.index(last, begin) + len(last)
    code = code[:begin] + new + code[end:]
replace_once('output_depth % 4 == 0', 'output_depth %% %d == 0' % block)
replace_once('oc += 4', 'oc += %d' % block)
replace_once('int32_t a0 = 0, a1 = 0, a2 = 0, a3 = 0;',
             'int32_t ' + ', '.join('a%d = 0' % i for i in range(block)) + ';')
weights = ['const int8_t* w0 = filter_data + base;']
weights += ['const int8_t* w%d = w%d + filter_stride;' % (i, i-1)
            for i in range(1, block)]
replace_region('const int8_t* w0 = filter_data + base;',
               'const int8_t* w3 = w2 + filter_stride;',
               '\n              '.join(weights))
updates = ['a%d += x * int32_t(w%d[ic]);' % (i, i) for i in range(block)]
replace_region('a0 += x * int32_t(w0[ic]);',
               'a3 += x * int32_t(w3[ic]);', '\n                '.join(updates))
replace_once('sums[4] = {a0, a1, a2, a3}',
             'sums[%d] = {%s}' % (block, ', '.join('a%d' % i for i in range(block))))
replace_once('j < 4', 'j < %d' % block)
dest = root.with_name('B1_block%d' % block)
assert not dest.exists(), 'Destination already exists: ' + str(dest)
skip = shutil.ignore_patterns('build', 'report', 'checkpoints', '__pycache__')
shutil.copytree(root, dest, ignore=skip)
(dest / 'src/conv_block4.inc').write_text(code)
(dest / 'blocking.txt').write_text('OC_BLOCK=%d\nSource=B1\n' % block)
print('Created:', dest)
