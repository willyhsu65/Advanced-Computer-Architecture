from pathlib import Path
import re
import shutil


def optimize(code):
    pattern = r'if\s*\(groups\s*==\s*1\s*&&\s*output_depth\s*%\s*(\d+)\s*==\s*0\s*\)\s*\{'
    matches = list(re.finditer(pattern, code))
    if len(matches) != 1:
        raise ValueError("Expected one original blocking guard")
    block = int(matches[0][1])
    if block not in (1, 2, 4, 8, 16, 32):
        raise ValueError("Unsupported blocking size")
    guard = (f"if (groups == 1 && output_depth % {block} == 0 &&\n"
             "    dilation_height_factor == 1 && dilation_width_factor == 1) {")
    code = code[:matches[0].start()] + guard + code[matches[0].end():]
    edits = [
        ("const int y0 = oy * stride_height - pad_height;",
         "const int y0 = oy * stride_height - pad_height;\n"
         "      const int fy_begin = std::max(0, -y0);\n"
         "      const int fy_end = std::min(filter_height, input_height - y0);"),
        ("const int x0 = ox * stride_width - pad_width;",
         "const int x0 = ox * stride_width - pad_width;\n"
         "        const int fx_begin = std::max(0, -x0);\n"
         "        const int fx_end = std::min(filter_width, input_width - x0);"),
        ("for (int fy = 0; fy < filter_height; ++fy)",
         "for (int fy = fy_begin; fy < fy_end; ++fy)"),
        ("for (int fx = 0; fx < filter_width; ++fx)",
         "for (int fx = fx_begin; fx < fx_end; ++fx)"),
        ("if (iy < 0 || iy >= input_height) continue;", ""),
        ("if (ix < 0 || ix >= input_width) continue;", ""),
    ]
    for old, new in edits:
        if code.count(old) != 1:
            raise ValueError("Unexpected kernel; no files changed: " + old)
        code = code.replace(old, new, 1)
    return code, block


def main():
    root = Path.cwd().resolve()
    kernel = Path("src/conv_block4.inc")
    header = Path("src/tensorflow/lite/micro/kernels/internal/reference/integer_ops/conv.h")
    if not Path("Makefile").is_file() or '"conv_block4.inc"' not in header.read_text():
        raise SystemExit("Run inside the B1 workload.")
    code, block = optimize(kernel.read_text())
    dest = root.with_name(root.name + "_bounds")
    if dest.exists():
        raise SystemExit("Destination already exists: " + str(dest))
    skip = shutil.ignore_patterns("build", "report", "checkpoints", "__pycache__")
    shutil.copytree(root, dest, ignore=skip)
    (dest / kernel).write_text(code)
    (dest / "bounds.txt").write_text(f"OC_BLOCK={block}\nSource={root.name}\n")
    print("Created:", dest)
    print("Preserved blocking:", block)

if __name__ == "__main__":
    main()
