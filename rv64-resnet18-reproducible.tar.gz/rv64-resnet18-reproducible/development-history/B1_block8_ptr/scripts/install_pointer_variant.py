from pathlib import Path
import re, shutil

root = Path.cwd().resolve()
k = Path("src/conv_block4.inc")
h = Path("src/tensorflow/lite/micro/kernels/internal/reference/integer_ops/conv.h")
assert Path("Makefile").is_file() and '"conv_block4.inc"' in h.read_text()
code = k.read_text()
assert "fy_begin" not in code, "Use the original block variant, not bounds"
blocks = re.findall(r'output_depth\s*%\s*(\d+)\s*==\s*0', code)
assert len(blocks) == 1
n = int(blocks[0])
assert n in (1, 2, 4, 8, 16, 32)

def edit(old, new):
    global code
    assert code.count(old) == 1, "Unexpected kernel: " + old
    code = code.replace(old, new, 1)

anchor = "if (iy < 0 || iy >= input_height) continue;"
edit(anchor, anchor + "\n"
     "            const int input_row_offset = Offset(input_shape, batch, iy, 0, 0);\n"
     "            const int filter_row_offset = oc * filter_stride + fy * filter_width * input_depth;")
edit("Offset(input_shape, batch, iy, ix, 0)", "(input_row_offset + ix * input_depth)")
pattern = r'oc\s*\*\s*filter_stride\s*\+\s*\(fy\s*\*\s*filter_width\s*\+\s*fx\)\s*\*\s*input_depth'
assert len(re.findall(pattern, code)) == 1
code = re.sub(pattern, "filter_row_offset + fx * input_depth", code, count=1)
edit("in[ic]", "*in++")
for j in range(n):
    edit(f"w{j}[ic]", f"*w{j}++")
dest = root.with_name(root.name + "_ptr")
assert not dest.exists(), "Destination already exists: " + str(dest)
skip = shutil.ignore_patterns("build", "report", "checkpoints", "__pycache__")
shutil.copytree(root, dest, ignore=skip)
(dest / k).write_text(code)
(dest / "pointer.txt").write_text(f"OC_BLOCK={n}\nSource={root.name}\n")
print("Created:", dest, "OC_BLOCK=", n)
