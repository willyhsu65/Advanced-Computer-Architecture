from pathlib import Path
import copy
import hashlib
import math
import re
import shutil
import flatbuffers
try:
    from tensorflow.lite.python import schema_py_generated as schema
except ImportError:
    import schema_generated as schema

RUNTIME = r'''
// Included inside frozen_ops.cc's anonymous namespace.
int OriginalTensorId(int i) {
  return i >= 0 && i < kOriginalTensorCount ? kOriginalTensorId[i] : -1;
}
struct ConvAddState { const FrozenNode* conv; const FrozenNode* add; };

TfLiteStatus PrepareConvAdd(TfLiteContext* c, TfLiteNode* node) {
  if (!node->inputs || node->inputs->size != 4 || !node->outputs ||
      node->outputs->size != 1 ||
      OriginalTensorId(node->outputs->data[0]) != kFusedAddTensor)
    return kTfLiteError;
  const FrozenNode* conv = nullptr;
  const FrozenNode* add = nullptr;
  for (const auto& n : kFrozenNodes) {
    if (n.kind == Kind::Conv && n.output == kFusedConvTensor) conv = &n;
    if (n.kind == Kind::Add && n.output == kFusedAddTensor) add = &n;
  }
  if (!conv || !add || conv->params_bytes != sizeof(ml::ConvParams) ||
      add->params_bytes != sizeof(ml::ArithmeticParams) ||
      !conv->multipliers || !conv->shifts) return kTfLiteError;
  const auto* x = ml::GetEvalInput(c, node, 0);
  const auto* w = ml::GetEvalInput(c, node, 1);
  const auto* b = ml::GetEvalInput(c, node, 2);
  const auto* skip = ml::GetEvalInput(c, node, 3);
  auto* out = ml::GetEvalOutput(c, node, 0);
  if (!x || !w || !b || !skip || !out || x->type != kTfLiteInt8 ||
      w->type != kTfLiteInt8 || b->type != kTfLiteInt32 ||
      skip->type != kTfLiteInt8 || out->type != kTfLiteInt8 ||
      x->dims->size != 4 || w->dims->size != 4 ||
      skip->dims->size != 4 || out->dims->size != 4 ||
      x->dims->data[3] != w->dims->data[3] ||
      w->dims->data[0] != out->dims->data[3] ||
      out->dims->data[3] % 4 != 0) return kTfLiteError;
  for (int i = 0; i < 4; ++i)
    if (skip->dims->data[i] != out->dims->data[i]) return kTfLiteError;
  auto* state = static_cast<ConvAddState*>(
      c->AllocatePersistentBuffer(c, sizeof(ConvAddState)));
  if (!state) return kTfLiteError;
  state->conv = conv;
  state->add = add;
  node->user_data = state;
  return kTfLiteOk;
}

TfLiteStatus InvokeConvAdd(TfLiteContext* c, TfLiteNode* node) {
  using ml::Offset;
  using ml::MultiplyByQuantizedMultiplier;
  const auto& state = *static_cast<const ConvAddState*>(node->user_data);
  const auto params = Params<ml::ConvParams>(*state.conv);
  auto add_params = Params<ml::ArithmeticParams>(*state.add);
  if (kFusedConvSlot == 1) {
    std::swap(add_params.input1_offset, add_params.input2_offset);
    std::swap(add_params.input1_multiplier, add_params.input2_multiplier);
    std::swap(add_params.input1_shift, add_params.input2_shift);
  }
  const auto* a = ml::GetEvalInput(c, node, 0);
  const auto* w = ml::GetEvalInput(c, node, 1);
  const auto* b = ml::GetEvalInput(c, node, 2);
  const auto* skip = ml::GetEvalInput(c, node, 3);
  auto* out = ml::GetEvalOutput(c, node, 0);
  const auto input_shape = ml::GetTensorShape(a);
  const auto filter_shape = ml::GetTensorShape(w);
  const auto output_shape = ml::GetTensorShape(out);
  const int8_t* input_data = a->data.int8;
  const int8_t* filter_data = w->data.int8;
  const int32_t* bias_data = b->data.i32;
  const int8_t* skip_data = skip->data.int8;
  int8_t* output_data = out->data.int8;
  const int32_t* output_multiplier = state.conv->multipliers;
  const int32_t* output_shift = state.conv->shifts;
  const int batches = input_shape.Dims(0);
  const int input_height = input_shape.Dims(1);
  const int input_width = input_shape.Dims(2);
  const int input_depth = input_shape.Dims(3);
  const int filter_height = filter_shape.Dims(1);
  const int filter_width = filter_shape.Dims(2);
  const int groups = input_depth / filter_shape.Dims(3);
  const int output_height = output_shape.Dims(1);
  const int output_width = output_shape.Dims(2);
  const int output_depth = output_shape.Dims(3);
  const int stride_height = params.stride_height;
  const int stride_width = params.stride_width;
  const int dilation_height_factor = params.dilation_height_factor;
  const int dilation_width_factor = params.dilation_width_factor;
  const int pad_height = params.padding_values.height;
  const int pad_width = params.padding_values.width;
  const int32_t input_offset = params.input_offset;
  const int32_t output_offset = params.output_offset;
  const int32_t output_activation_min = params.quantized_activation_min;
  const int32_t output_activation_max = params.quantized_activation_max;
#if !defined(__riscv)
  uint64_t conv_hash = UINT64_C(14695981039346656037);
  size_t conv_bytes = 0;
#endif
#include "conv_add_block4.inc"
  return kTfLiteError;
}

tflite::TFLMRegistration RegisterConvAdd() {
  tflite::TFLMRegistration r{};
  r.prepare = PrepareConvAdd;
  r.invoke = InvokeConvAdd;
  return r;
}
'''

root = Path.cwd().resolve()
assert root.name == 'B1', 'Run this installer from the B1 directory.'
dest = root.with_name('B1_fuse')
assert not dest.exists(), 'B1_fuse already exists; choose a new destination name.'
ops_source = (root / 'src/frozen_ops.cc').read_text()
kernel = (root / 'src/conv_block4.inc').read_text()
main = (root / 'src/main.cc').read_text()
ref = (root / 'generated/tflm_reference.h').read_text()
data_s = (root / 'src/data.S').read_text()
make = (root / 'Makefile').read_text()
paths = re.findall(r'\.incbin\s+"([^"\n]+\.tflite)"', data_s)
assert len(paths) == 1, 'Expected one .tflite incbin in src/data.S.'
model_path = paths[0]
blob = (root / model_path).read_bytes()
model = schema.ModelT.InitFromObj(schema.Model.GetRootAsModel(blob, 0))
assert len(model.subgraphs) == 1
g = model.subgraphs[0]
assert not any(t.isVariable for t in g.tensors)
ops = g.operators
old_count = len(ops)
def kind(op):
    return model.operatorCodes[op.opcodeIndex].builtinCode
producer = {int(t): i for i, op in enumerate(ops) for t in op.outputs}
consumers = {}
for i, op in enumerate(ops):
    for t in op.inputs:
        consumers.setdefault(int(t), []).append(i)
choice = None
for ai, add in enumerate(ops):
    if kind(add) != schema.BuiltinOperator.ADD or len(add.inputs) != 2:
        continue
    for slot, tensor in enumerate(add.inputs):
        tensor = int(tensor)
        ci = producer.get(tensor, -1)
        if ci != ai - 1 or ci < 0:
            continue
        conv = ops[ci]
        if (kind(conv) == schema.BuiltinOperator.CONV_2D and
            len(conv.inputs) == 3 and min(conv.inputs) >= 0 and
            consumers[tensor] == [ai] and tensor not in g.outputs):
            choice = ci, ai, slot, tensor
            break
    if choice:
        break
assert choice, 'No adjacent, single-consumer Conv+Add pair found.'
ci, ai, slot, mid = choice
conv, add = ops[ci], ops[ai]
out_id, skip_id = int(add.outputs[0]), int(add.inputs[1-slot])
shape = list(g.tensors[out_id].shape)
assert shape == list(g.tensors[mid].shape) == list(g.tensors[skip_id].shape)
assert len(shape) == 4 and shape[-1] % 4 == 0
for t in [int(conv.inputs[0]), int(conv.inputs[1]), mid, out_id, skip_id]:
    assert g.tensors[t].type == schema.TensorType.INT8
assert g.tensors[int(conv.inputs[2])].type == schema.TensorType.INT32
assert g.tensors[int(conv.inputs[0])].shape[-1] == g.tensors[int(conv.inputs[1])].shape[-1]

row_re = re.compile(r'\{\s*(\d+)\s*,\s*(\d+)\s*,\s*UINT64_C\(\s*(0x[0-9a-fA-F]+|\d+)\s*\)\s*\}\s*,?')
rows = [(int(a), int(b), int(h, 0)) for a,b,h in row_re.findall(ref)]
assert len(rows) == old_count, 'Reference rows must match original operator count.'
assert all(rows[i][0] == int(op.outputs[0]) for i,op in enumerate(ops))
assert rows[ci][0] == mid and rows[ci][1] == math.prod(shape)
new_to_old = [i for i in range(len(g.tensors)) if i != mid]
old_to_new = {old: new for new,old in enumerate(new_to_old)}
def remap(values):
    return [old_to_new[int(v)] if v >= 0 else -1 for v in values]

opcode = schema.OperatorCodeT()
opcode.builtinCode = schema.BuiltinOperator.CUSTOM
opcode.deprecatedBuiltinCode = schema.BuiltinOperator.CUSTOM
opcode.customCode = b'FROZEN_CONV_ADD'
opcode.version = 1
fused = schema.OperatorT()
fused.opcodeIndex = len(model.operatorCodes)
fused.inputs = list(map(int, conv.inputs)) + [skip_id]
fused.outputs = [out_id]
model.operatorCodes.append(opcode)
g.operators = [fused if i == ai else op for i,op in enumerate(ops) if i != ci]
for op in g.operators:
    op.inputs, op.outputs = remap(op.inputs), remap(op.outputs)
    if op.intermediates is not None:
        op.intermediates = remap(op.intermediates)
g.inputs, g.outputs = remap(g.inputs), remap(g.outputs)
g.tensors = [g.tensors[i] for i in new_to_old]
for sig in model.signatureDefs or []:
    for item in list(sig.inputs or []) + list(sig.outputs or []):
        item.tensorIndex = old_to_new[int(item.tensorIndex)]
def text_name(x):
    return x.decode() if isinstance(x, bytes) else x
model.metadata = [x for x in (model.metadata or [])
                  if text_name(x.name) != 'OfflineMemoryAllocation']
builder = flatbuffers.Builder(0)
builder.Finish(model.Pack(builder), file_identifier=b'TFL3')
new_blob = bytes(builder.Output())
check = schema.Model.GetRootAsModel(new_blob, 0)
assert check.Subgraphs(0).OperatorsLength() == old_count - 1
assert check.Subgraphs(0).TensorsLength() == len(new_to_old)
original_model = schema.Model.GetRootAsModel(blob, 0)
assert check.BuffersLength() == original_model.BuffersLength()
for i in range(check.BuffersLength()):
    before, after = original_model.Buffers(i), check.Buffers(i)
    assert before.DataLength() == after.DataLength()
    if before.DataLength():
        assert before.DataAsNumpy().tobytes() == after.DataAsNumpy().tobytes()

store = 'output_data[dst + j] = static_cast<int8_t>(value);'
assert kernel.count(store) == 1 and kernel.count('return;') == 1
positions = [kernel.index('for (int ' + n) for n in ('batch','oy','ox','oc','fy','fx','ic')]
assert positions == sorted(positions), 'Host hash requires the original output traversal order.'
kernel = kernel.replace(store, '''const int8_t conv_value = static_cast<int8_t>(value);
#if !defined(__riscv)
            conv_hash = (conv_hash ^ static_cast<uint8_t>(conv_value)) *
                UINT64_C(1099511628211);
            ++conv_bytes;
#endif
            output_data[dst + j] =
                ri::AddFunc(conv_value, skip_data[dst + j], add_params);''')
kernel = kernel.replace('return;', '''#if !defined(__riscv)
  if (conv_hash != kFusedConvHash || conv_bytes != kFusedConvBytes) {
    platform_log("Fusion pre-Add Conv: MISMATCH\\n");
    return kTfLiteError;
  }
  platform_log("Fusion pre-Add Conv: PASS\\n");
#endif
  return kTfLiteOk;''')
anchor = 'template<Kind K> TfLiteStatus Prepare'
assert ops_source.count(anchor) == 1
ops_source = ops_source.replace(anchor, '#include "conv_add_fused.inc"\n' + anchor)
old_lookup = 'n.output==node->outputs->data[0]'
assert ops_source.count(old_lookup) == 1
ops_source = ops_source.replace(old_lookup, 'n.output==OriginalTensorId(node->outputs->data[0])')
ops_source = '#include <algorithm>\n#include "platform.h"\n#include "fusion_config.h"\n' + ops_source
ops_source, count = re.subn(r'(TfLiteStatus AddModelOps\([^\n]+\)\s*\{)',
    r'\1\n  const auto fused_registration = RegisterConvAdd();\n'
    r'  if (r.AddCustom("FROZEN_CONV_ADD", &fused_registration) != kTfLiteOk) return kTfLiteError;',
    ops_source)
assert count == 1
new_count = old_count - 1
assert new_count == 36, 'This prototype expects the original 37-node model.'
prefix = ref[:ref.index('struct OpReference')]
new_ref = prefix + 'struct OpReference { int tensor; size_t bytes; uint64_t hash; };\nconstexpr OpReference kOpReference[] = {\n'
for i,(tensor,size,h) in enumerate(rows):
    if i != ci:
        new_ref += '{%d,%d,UINT64_C(0x%016x)},\n' % (old_to_new[tensor],size,h)
new_ref += '};\nconstexpr unsigned kOpCount=%d;\n' % new_count
config = ('#pragma once\n#include <cstddef>\n#include <cstdint>\n'
    'constexpr int kOriginalTensorCount=%d;\nconstexpr int kOriginalTensorId[]={%s};\n'
    'constexpr int kFusedConvTensor=%d, kFusedAddTensor=%d, kFusedConvSlot=%d;\n'
    'constexpr size_t kFusedConvBytes=%d;\nconstexpr uint64_t kFusedConvHash=UINT64_C(0x%016x);\n'
    % (len(new_to_old),','.join(map(str,new_to_old)),mid,out_id,slot,rows[ci][1],rows[ci][2]))
new_model_path = 'models/resnet18_int8_conv_add.tflite'
new_data_s = data_s.replace('"'+model_path+'"', '"'+new_model_path+'"')
make_lines = make.splitlines(keepends=True)
for i,line in enumerate(make_lines):
    if 'src/data.o:' in line:
        make_lines[i] = line.replace(model_path,new_model_path)
new_make = ''.join(make_lines)
assert new_model_path in new_make, 'Could not update literal data.o model dependencies.'
new_make += '\nifneq ($(MODE),frozen)\n$(error Conv+Add prototype supports MODE=frozen only)\nendif\n'
capacity = re.compile(r'MicroMutableOpResolver\s*<\s*7\s*>')
assert capacity.search(ops_source) and capacity.search(main)
assert 'MicroMutableOpResolver<7>' in (root/'src/frozen_ops.h').read_text()

shutil.copytree(root, dest, ignore=shutil.ignore_patterns('build','report','checkpoints','__pycache__'))
(dest/new_model_path).write_bytes(new_blob)
(dest/'src/frozen_ops.cc').write_text(ops_source)
(dest/'src/conv_add_fused.inc').write_text(RUNTIME)
(dest/'src/conv_add_block4.inc').write_text(kernel)
(dest/'generated/fusion_config.h').write_text(config)
(dest/'generated/tflm_reference.h').write_text(new_ref)
(dest/'src/data.S').write_text(new_data_s)
(dest/'Makefile').write_text(new_make)
for p in (dest/'src').rglob('*'):
    if p.suffix in ('.cc','.h'):
        s = p.read_text()
        updated = capacity.sub('MicroMutableOpResolver<8>',s)
        if p.name == 'main.cc':
            updated = updated.replace('/37','/36')
        if updated != s:
            p.write_text(updated)
(dest/'fusion-info.txt').write_text(
    'Original model SHA256: '+hashlib.sha256(blob).hexdigest()+'\n'
    'Fused model SHA256: '+hashlib.sha256(new_blob).hexdigest()+'\n'
    'Original Conv node: %d; Add node: %d; removed tensor: %d\n' % (ci,ai,mid)+
    'Reference hashes retained; tensor indices remapped; offline layout removed.\n')
print('Created:', dest)
print('Fused original nodes:', ci, '+', ai, '; removed tensor:', mid)
print('Operators:', old_count, '->', new_count, '; tensors:', len(new_to_old)+1, '->', len(new_to_old))
print('All original buffer bytes and all retained reference hashes preserved.')
print('Next: cd ../B1_fuse, then build MODE=frozen host-run.')
