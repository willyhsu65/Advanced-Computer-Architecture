from pathlib import Path
import re
from requant_metrics import analyze, table_rows, extend_table

wrapper = '''
# BEGIN REQUANT TABLE WRAPPER
_render_before_requant = render

def render(data):
    from requant_metrics import extend_table
    return extend_table(_render_before_requant(data), data)
# END REQUANT TABLE WRAPPER
'''
patches = [
    ("scripts/measure_metrics.py", "    (out / 'metrics.json').write_text",
     "    from requant_metrics import analyze\n"
     "    result['requantization'] = analyze(out / 'disassembly.txt', histogram, args.hist_scope)\n"),
    ("scripts/metrics_table.py", None, wrapper),
]
pending = []
for filename, anchor, hook in patches:
    path = Path(filename)
    source = path.read_text()
    if anchor is None:
        if "# BEGIN REQUANT TABLE WRAPPER" in source:
            continue
        if not re.search(r'(?m)^def render\(', source):
            raise SystemExit("No render function; no changes made: " + filename)
        updated = source + "\n" + hook
    else:
        if source.count(hook) == 1:
            continue
        if hook in source or source.count(anchor) != 1:
            raise SystemExit("Unexpected file layout; no changes made: " + filename)
        updated = source.replace(anchor, hook + anchor, 1)
    compile(updated, filename, "exec")
    pending.append((path, updated))

for path, updated in pending:
    backup = path.with_name(path.name + ".before-requant")
    if not backup.exists():
        backup.write_bytes(path.read_bytes())
    path.write_text(updated)
print("Installed: make metrics / make profile -> requantization rows and JSON")
