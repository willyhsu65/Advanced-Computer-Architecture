from pathlib import Path
import re

root = Path.cwd().resolve()
assert root.name == "X2" and (root / "Makefile").is_file(), "Run inside X2"

payload = {}
payload["src/x2_requant_math.inc"] = r'''
// No include guard: also included inside Spike instruction functions.
class X2RequantMath {
 public:
  static int S8(uint64_t x) {
    int v = int(x & 255);
    return v < 128 ? v : v - 256;
  }
  static int64_t S32(uint64_t x) {
    uint32_t v = uint32_t(x);
    return (v & 0x80000000u) ? int64_t(v) - 0x100000000LL : int64_t(v);
  }
  static int64_t ASR(int64_t x, unsigned s) {
    if (!s) return x;
    const int64_t d = int64_t(1) << s;
    return x >= 0 ? x / d : -1 - ((-1 - x) / d);
  }
  static bool Valid(uint64_t m, uint64_t c) {
    return S32(m) >= 0 && !(c >> 33) &&
           S8(c) >= -31 && S8(c) <= 30 &&
           S8(c >> 16) <= S8(c >> 24);
  }
  static uint64_t Pack(int s, int z, int lo, int hi, bool single) {
    return uint64_t(uint8_t(s)) |
           (uint64_t(uint8_t(z)) << 8) |
           (uint64_t(uint8_t(lo)) << 16) |
           (uint64_t(uint8_t(hi)) << 24) |
           (uint64_t(single) << 32);
  }
  static int64_t Execute(uint64_t oldrd, uint64_t mult, uint64_t ctl) {
    const int64_t x = S32(oldrd), m = S32(mult);
    const int shift = S8(ctl);
    int64_t y;
    if ((ctl >> 32) & 1) {
      const unsigned s = unsigned(31 - shift);
      y = S32(uint64_t(ASR(x*m + (int64_t(1) << (s-1)), s)));
    } else {
      const unsigned left = shift > 0 ? unsigned(shift) : 0;
      const unsigned right = shift < 0 ? unsigned(-shift) : 0;
      const int64_t product = S32(uint64_t(uint32_t(x)) << left) * m;
      const int64_t nudge = product >= 0 ?
          (int64_t(1) << 30) : 1 - (int64_t(1) << 30);
      const int64_t high = (product + nudge) / (int64_t(1) << 31);
      const uint32_t mask = uint32_t((uint64_t(1) << right) - 1);
      const uint32_t rem = uint32_t(high) & mask;
      const uint32_t threshold = (mask >> 1) + (high < 0);
      y = ASR(high, right) + (rem > threshold);
    }
    y = S32(uint64_t(y + S8(ctl >> 8)));
    const int lo = S8(ctl >> 16), hi = S8(ctl >> 24);
    return y < lo ? lo : y > hi ? hi : y;
  }
};
'''

payload["src/x2_requant.h"] = r'''#pragma once
#include <cstdint>
#include "tensorflow/lite/micro/kernels/internal/common.h"
#include "x2_requant_math.inc"

namespace x2 {
#if defined(TFLITE_SINGLE_ROUNDING) && TFLITE_SINGLE_ROUNDING
constexpr bool kSingle = true;
#else
constexpr bool kSingle = false;
#endif

inline int64_t Run(int64_t acc, uint64_t multiplier, uint64_t control) {
#if defined(__riscv) && (__riscv_xlen == 64)
  asm volatile(
      ".insn r 0x0b, 1, 0, %0, %1, %2"
      : "+r"(acc)
      : "r"(multiplier), "r"(control));
  return acc;
#else
  return X2RequantMath::Execute(uint64_t(acc), multiplier, control);
#endif
}

inline int32_t Requantize(int32_t acc, int32_t multiplier, int shift,
                          int offset, int lo, int hi) {
  if (multiplier >= 0 && shift >= -31 && shift <= 30 &&
      offset >= -128 && offset <= 127 &&
      lo >= -128 && hi <= 127 && lo <= hi) {
    return int32_t(Run(
        acc, uint32_t(multiplier),
        X2RequantMath::Pack(shift, offset, lo, hi, kSingle)));
  }

  int32_t value = ::tflite::micro::MultiplyByQuantizedMultiplier(
      acc, multiplier, shift);
  value += offset;
  return value < lo ? lo : value > hi ? hi : value;
}
}
'''

payload["src/qrequant8_test.cc"] = r'''#include <cstdint>
#include <initializer_list>
#include "platform.h"
#include "x2_requant.h"

static unsigned checks = 0;

static bool Check(int32_t x, int32_t m, int shift,
                  int z, int lo, int hi) {
  if (shift > 0) {
    int64_t scaled = int64_t(x) * (int64_t(1) << shift);
    if (scaled < -2147483648LL || scaled > 2147483647LL)
      return true;
  }
  int64_t expected =
      ::tflite::micro::MultiplyByQuantizedMultiplier(x, m, shift);
  expected += z;
  if (expected < -2147483648LL || expected > 2147483647LL)
    return true;
  if (expected < lo) expected = lo;
  if (expected > hi) expected = hi;
  const uint64_t ctl = X2RequantMath::Pack(
      shift, z, lo, hi, x2::kSingle);
  const int64_t oldrd =
      int64_t(uint32_t(x)) | (int64_t(0x13579bdf) << 32);
  const int64_t actual = x2::Run(oldrd, uint32_t(m), ctl);
  if (actual != expected) {
    platform_log(
        "FAIL x=%d m=%d s=%d z=%d lo=%d hi=%d got=%lld ref=%lld\n",
        x, m, shift, z, lo, hi,
        (long long)actual, (long long)expected);
    return false;
  }
  ++checks;
  return true;
}

static bool Aliases() {
  const uint64_t c = X2RequantMath::Pack(
      0, 0, -128, 127, x2::kSingle);
  for (int kind = 0; kind < 7; ++kind) {
    uint64_t m = 0x40000000, control = c;
    int64_t a = -27;
    if (kind == 0) a = int64_t(m);
    if (kind == 1) a = int64_t(control);
    if (kind == 2) m = uint32_t(control);
    if (kind == 3) {
      a = int64_t(control);
      m = uint32_t(control);
    }
    if (kind == 4) m = 0;
    if (kind == 5) { m = 0; control = 0; }
    int64_t expected = kind == 6 ? 0 :
        ::tflite::micro::MultiplyByQuantizedMultiplier(
            int32_t(X2RequantMath::S32(uint64_t(a))),
            int32_t(m), 0);
    if (kind == 5) expected = 0;
    if (expected < -128) expected = -128;
    if (expected > 127) expected = 127;
#if defined(__riscv) && (__riscv_xlen == 64)
    if (kind == 0)
      asm volatile(".insn r 0x0b,1,0,%0,%0,%1"
          : "+r"(a) : "r"(control));
    if (kind == 1)
      asm volatile(".insn r 0x0b,1,0,%0,%1,%0"
          : "+r"(a) : "r"(m));
    if (kind == 2)
      asm volatile(".insn r 0x0b,1,0,%0,%1,%1"
          : "+r"(a) : "r"(control));
    if (kind == 3)
      asm volatile(".insn r 0x0b,1,0,%0,%0,%0" : "+r"(a));
    if (kind == 4)
      asm volatile(".insn r 0x0b,1,0,%0,zero,%1"
          : "+r"(a) : "r"(control));
    if (kind == 5)
      asm volatile(".insn r 0x0b,1,0,%0,%1,zero"
          : "+r"(a) : "r"(m));
    if (kind == 6) {
      asm volatile(".insn r 0x0b,1,0,zero,%0,%1"
          :: "r"(m), "r"(control));
      asm volatile("mv %0,zero" : "=r"(a));
    }
#else
    a = kind == 6 ? 0 : x2::Run(a, m, control);
#endif
    if (a != expected) {
      platform_log("QREQUANT8 ALIAS FAIL: %d\n", kind);
      return false;
    }
    ++checks;
  }
  return true;
}
'''

payload["src/qrequant8_test.cc"] += r'''
static uint64_t Next(uint64_t& s) {
  s ^= s << 13;
  s ^= s >> 7;
  s ^= s << 17;
  return s;
}

struct BenchInput {
  int32_t x, m;
  int shift, z, lo, hi;
  uint64_t control;
};

__attribute__((noinline,noclone))
static bool Bench() {
  static BenchInput input[256];
  static volatile int32_t sw[4096], hw[4096];
  uint64_t state = 0x987654321ULL;
  for (int i = 0; i < 256; ++i) {
    auto& p = input[i];
    p.x = int(Next(state) % 65536) - 32768;
    p.m = int32_t(0x40000000u +
        uint32_t(Next(state) % 0x40000000u));
    p.shift = -1 - int(Next(state) % 16);
    p.z = int(Next(state) % 256) - 128;
    p.lo = -128 + int(Next(state) % 129);
    p.hi = p.lo + int(Next(state) % unsigned(128 - p.lo));
    p.control = X2RequantMath::Pack(
        p.shift, p.z, p.lo, p.hi, x2::kSingle);
  }

  asm volatile(".global rq_sw_begin\nrq_sw_begin:" ::: "memory");
  for (int i = 0; i < 4096; ++i) {
    const auto& p = input[i & 255];
    int32_t value = ::tflite::micro::MultiplyByQuantizedMultiplier(
        p.x, p.m, p.shift);
    value += p.z;
    if (value < p.lo) value = p.lo;
    if (value > p.hi) value = p.hi;
    sw[i] = value;
  }
  asm volatile(".global rq_sw_end\nrq_sw_end:" ::: "memory");
  asm volatile("nop" ::: "memory");
  asm volatile(".global rq_hw_begin\nrq_hw_begin:" ::: "memory");
  for (int i = 0; i < 4096; ++i) {
    const auto& p = input[i & 255];
    hw[i] = int32_t(x2::Run(p.x, uint32_t(p.m), p.control));
  }
  asm volatile(".global rq_hw_end\nrq_hw_end:" ::: "memory");

  for (int i = 0; i < 4096; ++i)
    if (sw[i] != hw[i]) return false;
  platform_log("REQUANT BENCH PASS: 4096 outputs\n");
  return true;
}
'''

payload["src/qrequant8_test.cc"] += r'''
int main() {
  platform_log("QREQUANT8 TEST: SINGLE_ROUNDING=%d\n",
      int(x2::kSingle));
  const int32_t xs[] = {
      -2147483647-1, 2147483647,
      -129, -128, -7, -3, -1, 0, 1, 3, 7, 127, 128};
  const int32_t ms[] = {0, 1, 0x40000000, 0x7fffffff};
  const int ss[] = {-31, -16, -1, 0, 1, 7, 30};

  for (int32_t x : xs)
    for (int32_t m : ms)
      for (int s : ss)
        for (int z : {-128, 0, 127})
          if (!Check(x, m, s, z, -128, 127)) return 1;

  uint64_t state = 0x123456789abcdefULL;
  while (checks < 100000) {
    int32_t x = int32_t(X2RequantMath::S32(Next(state)));
    int32_t m = int32_t(Next(state) & 0x7fffffff);
    int s = int(Next(state) % 62) - 31;
    int z = int(Next(state) % 256) - 128;
    int lo = int(Next(state) % 256) - 128;
    int hi = lo + int(Next(state) % unsigned(128 - lo));
    if (!Check(x, m, s, z, lo, hi)) return 2;
  }

  if (!Aliases()) return 3;
  const uint64_t c = X2RequantMath::Pack(
      0, 0, -128, 127, x2::kSingle);
  if (X2RequantMath::Valid(0x80000000, c) ||
      X2RequantMath::Valid(1, c | (uint64_t(1) << 33)) ||
      X2RequantMath::Valid(1, X2RequantMath::Pack(
          -32, 0, -128, 127, x2::kSingle)) ||
      X2RequantMath::Valid(1, X2RequantMath::Pack(
          0, 0, 10, -10, x2::kSingle))) return 4;

  if (!Bench()) {
    platform_log("REQUANT BENCH FAIL\n");
    return 5;
  }
  platform_log("QREQUANT8 TEST PASS: %u checks\n", checks);
  return 0;
}
'''

payload["scripts/requant_test.mk"] = '''RQ_H_COMMON := $(filter %/kernels/internal/common.o %/micro_log.o,$(HOST_OBJ))
RQ_R_COMMON := $(filter %/kernels/internal/common.o %/micro_log.o,$(RV_OBJ))
.PHONY: requant-host-test requant-spike-test
requant-host-test: build/host-$(MODE)/qrequant8_test
\t./$<
build/host-$(MODE)/qrequant8_test: build/host-$(MODE)/src/qrequant8_test.o $(RQ_H_COMMON) build/host-$(MODE)/src/platform_host.o
\t$(CXX) $^ -Wl,--gc-sections -o $@
requant-spike-test: build/qrequant8-test.elf
build/qrequant8-test.elf: build/rv64-$(MODE)/src/qrequant8_test.o $(RQ_R_COMMON) build/rv64-$(MODE)/src/platform_spike.o build/rv64-$(MODE)/src/start.o build/rv64-$(MODE)/vendor/printf/printf.o src/link.ld
\t@mkdir -p $(dir $@)
\t$(RISCV_PREFIX)g++ $(RVCOMMON) -nostartfiles --specs=nosys.specs -Wl,--gc-sections,--no-relax -Tsrc/link.ld $(filter %.o,$^) -o $@
-include build/host-$(MODE)/src/qrequant8_test.d build/rv64-$(MODE)/src/qrequant8_test.d
'''

payload["scripts/measure_requant.py"] = r'''from pathlib import Path
import hashlib
import json
import os
import re
import subprocess

root = Path(__file__).resolve().parents[1]
project = root.parent.parent
elf = root / "build/qrequant8-test.elf"
spike = project / "tools/riscv-isa-sim/build-gcc12/spike"
math_a = root / "src/x2_requant_math.inc"
math_b = project / "tools/riscv-isa-sim/riscv/insns/qrequant8_math.inc"
assert math_a.read_bytes() == math_b.read_bytes(), "Requant math differs"
prefix = os.environ.get("RISCV_PREFIX") or str(
    project / "tools/xpack-riscv-none-embed-gcc-10.2.0-1.2/bin/riscv-none-embed-")

names = ("rq_sw_begin", "rq_sw_end", "rq_hw_begin", "rq_hw_end")
symbols = {}
listing = subprocess.check_output(
    [prefix + "nm", "-n", str(elf)], text=True)
for line in listing.splitlines():
    fields = line.split()
    if len(fields) == 3 and fields[2] in names:
        assert fields[2] not in symbols, "Duplicate marker"
        symbols[fields[2]] = int(fields[0], 16)
assert len(symbols) == 4, "Missing benchmark markers"
assert len(set(symbols.values())) == 4, "Overlapping markers"

out = root / "results/requant"
out.mkdir(parents=True, exist_ok=True)
(out / "metrics.json").unlink(missing_ok=True)
commands = out / "debug.cmd"
commands.write_text("".join(
    f"until pc 0 {symbols[n]:x}\npc 0\nreg 0 minstret\n"
    for n in names) + "rs\n")

print("Requant test Spike:", spike, flush=True)
with (out / "stdout.txt").open("w") as stdout:
    with (out / "stderr.txt").open("w") as stderr:
        subprocess.run(
            [str(spike), "--isa=RV64IMC", "-m128", "-d",
             "--debug-cmd=" + str(commands), str(elf)],
            stdout=stdout, stderr=stderr, check=True, timeout=120)

values = re.findall(
    r"(?m)^\s*(?::\s*)?(0x[0-9a-fA-F]{1,16})[ \t]*$",
    (out / "stderr.txt").read_text())
assert len(values) == 8, "Inspect results/requant/stderr.txt"
values = [int(v, 16) for v in values]
assert values[::2] == [symbols[n] for n in names], "Wrong PCs"
sw, hw = values[3] - values[1], values[7] - values[5]
assert sw > 0 and hw > 0
log = (out / "stdout.txt").read_text()
assert "QREQUANT8 TEST PASS" in log and "REQUANT BENCH PASS" in log

data = dict(
    elf_sha256=hashlib.sha256(elf.read_bytes()).hexdigest(),
    outputs=4096, software_retired=sw, custom_retired=hw,
    software_instructions_per_output=sw / 4096,
    custom_instructions_per_output=hw / 4096,
    instruction_reduction_factor=sw / hw)
(out / "metrics.json").write_text(json.dumps(data, indent=2) + "\n")
print(log.strip())
print("| Version | Retired instructions | Instructions/output |")
print("|---|---:|---:|")
print(f"| Original TFLM | {sw:,} | {sw/4096:.4f} |")
print(f"| QREQUANT8 | {hw:,} | {hw/4096:.4f} |")
print(f"Instruction reduction factor: {sw/hw:.4f}x")
print("Scope: kernel loops, including loads/stores and loop control.")
print("Parameter preparation is outside these microbenchmark regions.")
'''

r = root / "../../tools/riscv-isa-sim/riscv"
inc = root / "src/conv_block4.inc"
hdr = root / "src/tensorflow/lite/micro/kernels/internal/reference/integer_ops/conv.h"
enc, mk = r / "encoding.h", r / "riscv.mk.in"
s, h = inc.read_text(), hdr.read_text()
e, m = enc.read_text(), mk.read_text()
assert "X1_PACKED_CONV" in s, "Expected the X1 packed Conv"
assert "X2_FUSED_REQUANT" not in s, "X2 already installed"
assert "MATCH_QMAC8" in e and "MATCH_QREQUANT8" not in e

pattern = (
    r"value\s*=\s*MultiplyByQuantizedMultiplier\(\s*value\s*,\s*"
    r"output_multiplier\[c\]\s*,\s*output_shift\[c\]\s*\);\s*"
    r"value\s*\+=\s*output_offset\s*;\s*"
    r"value\s*=\s*std::max\(\s*value\s*,\s*output_activation_min\s*\)\s*;\s*"
    r"value\s*=\s*std::min\(\s*value\s*,\s*output_activation_max\s*\)\s*;")

def fused(match):
    return (
        "if (x2_fused) {\n"
        "  value = int32_t(::x2::Run(value,\n"
        "      uint32_t(output_multiplier[c]), x2_control[c]));\n"
        "} else {\n" + match[0] + "\n}")

s, n = re.subn(pattern, fused, s)
assert n == 2, f"Expected two Conv epilogues, found {n}; no files changed"

s = '''// X2_FUSED_REQUANT
static uint64_t x2_control[512];
bool x2_fused = groups == 1 && output_depth > 0 &&
    output_depth <= 512 && output_depth % 8 == 0 &&
    output_offset >= -128 && output_offset <= 127 &&
    output_activation_min >= -128 && output_activation_max <= 127 &&
    output_activation_min <= output_activation_max;
if (x2_fused) {
  for (int c = 0; c < output_depth; ++c) {
    if (output_multiplier[c] < 0 ||
        output_shift[c] < -31 || output_shift[c] > 30) {
      x2_fused = false;
      break;
    }
    x2_control[c] = X2RequantMath::Pack(
        output_shift[c], output_offset,
        output_activation_min, output_activation_max, ::x2::kSingle);
  }
}
''' + s
h = '#include "x2_requant.h"\n' + h

defs = {k: int(v, 0) for k, v in re.findall(
    r"(?m)^#define[ \t]+(\w+)[ \t]+(0x[0-9a-fA-F]+|\d+)\b", e)}
for name, value, mask in re.findall(
        r"DECLARE_INSN\(\s*(\w+)\s*,\s*(\w+)\s*,\s*(\w+)\s*\)", e):
    if value in defs and mask in defs:
        assert ((0x100b ^ defs[value]) &
                (0xfe00707f & defs[mask])) != 0, "Encoding collision: " + name

def once(text, pattern, replacement):
    result, count = re.subn(
        pattern, lambda match: replacement + match[0], text)
    assert count == 1, "Unexpected source layout: " + pattern
    return result

e = once(e, r"(?m)^#define[ \t]+MATCH_QMAC8[ \t]+[^\n]+$",
         "#define MATCH_QREQUANT8 0x0000100b\n"
         "#define MASK_QREQUANT8 0xfe00707f\n")
e = once(e,
         r"DECLARE_INSN\(\s*qmac8\s*,\s*MATCH_QMAC8\s*,\s*MASK_QMAC8\s*\)",
         "DECLARE_INSN(qrequant8, MATCH_QREQUANT8, MASK_QREQUANT8)\n")
anchor = list(re.finditer(
    r"(?m)^riscv_insn_list[ \t]*=[ \t]*\\[ \t]*$", m))
assert len(anchor) == 1, "Cannot find Spike instruction list"
pos = anchor[0].end()
m = m[:pos] + "\n\tqrequant8 \\" + m[pos:]

makefile = root / "Makefile"
main_make = makefile.read_text()
assert "requant_test.mk" not in main_make
main_make += "\n-include scripts/requant_test.mk\n"

new_files = {
    r / "insns/qrequant8.h": '''require_rv64;
#include "qrequant8_math.inc"
const uint64_t acc = READ_REG(insn.rd());
const uint64_t multiplier = RS1, control = RS2;
require(X2RequantMath::Valid(multiplier, control));
WRITE_RD(reg_t(X2RequantMath::Execute(acc, multiplier, control)));
''',
    r / "insns/qrequant8_math.inc": payload["src/x2_requant_math.inc"],
    root / "scripts/spike_cxx.sh": '''#!/usr/bin/env bash
set -euo pipefail
args=()
for arg in "$@"; do
  case "$arg" in
    -Werror|-Werror=*) args+=("-Wno-error${arg#-Werror}") ;;
    *) args+=("$arg") ;;
  esac
done
exec x86_64-conda-linux-gnu-c++ "${args[@]}"
''',
}
changes = {inc: s, hdr: h, enc: e, mk: m, makefile: main_make}
expected = {
    "src/x2_requant_math.inc", "src/x2_requant.h",
    "src/qrequant8_test.cc", "scripts/requant_test.mk",
    "scripts/measure_requant.py"}
assert set(payload) == expected, "Missing payload section"
assert "int main()" in payload["src/qrequant8_test.cc"], "Missing part 5"
assert "static bool Bench()" in payload["src/qrequant8_test.cc"], "Missing part 4"
compile(payload["scripts/measure_requant.py"], "measure_requant.py", "exec")

for name, text in payload.items():
    p = root / name
    assert not p.exists() or p.read_text() == text, "Existing file differs: " + str(p)
for p in changes:
    backup = p.with_name(p.name + ".pre-qrequant8")
    assert not backup.exists(), "Backup exists: " + str(backup)
for p in new_files:
    assert not p.exists(), "File exists: " + str(p)

for name, text in payload.items():
    p = root / name
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text)
for p, text in changes.items():
    p.with_name(p.name + ".pre-qrequant8").write_bytes(p.read_bytes())
    p.write_text(text)
for p, text in new_files.items():
    p.write_text(text)
(root / "scripts/spike_cxx.sh").chmod(0o755)
print("PASS: QREQUANT8 installed in Spike and both Conv epilogues")
print("Extra control buffer: 4096 bytes; preparation remains inside Invoke")
