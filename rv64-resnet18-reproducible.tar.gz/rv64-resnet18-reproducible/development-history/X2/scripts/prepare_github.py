import tokenize

def read_python(path):
    with tokenize.open(path) as f:
        return f.read()

from pathlib import Path
import ast
import csv
import shutil
import subprocess

root = Path.cwd().resolve()
assert root.name == "X2", "Run inside workloads/X2"
project = root.parent.parent
versions = ["B0", "B1_block8_ptr", "X1", "X2"]
stage = project / "github-submission"
assert not stage.exists(), "Destination already exists: " + str(stage)

for version in versions:
    assert (root.parent / version / "Makefile").is_file(), (
        "Missing: " + version)

spike = project / "tools/riscv-isa-sim"
def spike_git(args, **kwargs):
    return subprocess.check_output(args, cwd=spike, **kwargs)

commit = spike_git(
    ["git", "rev-parse", "HEAD"],
    text=True).strip()
patch = spike_git(
    ["git", "diff", "--binary", "HEAD", "--", "riscv"])
new = spike_git(
    ["git", "ls-files",
     "--others", "--exclude-standard", "--", "riscv"],
    text=True).splitlines()

stage.mkdir()
for name in ("docs", "tests", "slides", "results", "spike/new-files"):
    (stage / name).mkdir(parents=True, exist_ok=True)

ignore = shutil.ignore_patterns(
    ".git", "__pycache__", "*.pyc", "*.broken",
    "*.pre-*", "*.o", "*.elf")
excluded = []

for version in versions:
    print("Collecting:", version, flush=True)
    source = root.parent / version
    dest = stage / "workloads" / version
    dest.mkdir(parents=True)
    shutil.copy2(source / "Makefile", dest / "Makefile")

    for name in (
        "src", "generated", "models", "reference",
        "vendor", "scripts", "tests"
    ):
        if (source / name).is_dir():
            shutil.copytree(source / name, dest / name, ignore=ignore)

    scripts = dest / "scripts"
    if scripts.is_dir():
        for path in sorted(scripts.rglob("*")):
            if not path.is_file():
                continue
            reason = None
            if path.suffix == ".py":
                try:
                    ast.parse(read_python(path))
                except (SyntaxError, UnicodeError) as exc:
                    reason = str(exc)
            elif path.suffix == ".sh":
                result = subprocess.run(
                    ["bash", "-n", str(path)],
                    capture_output=True, text=True)
                if result.returncode:
                    reason = result.stderr.strip()
            if reason:
                excluded.append((str(path.relative_to(stage)), reason))
                path.unlink()

    for folder in ("report", "results/node-profile", "results/requant"):
        old = source / folder
        if not old.is_dir():
            continue
        target = stage / "results" / version / folder
        for path in old.iterdir():
            if not path.is_file():
                continue
            allowed = path.suffix in (".json", ".csv", ".md")
            allowed |= path.name in (
                "summary.txt", "metrics.txt", "cache.txt",
                "run.log", "stdout.txt", "stderr.txt")
            if allowed and path.stat().st_size <= 1024 * 1024:
                target.mkdir(parents=True, exist_ok=True)
                shutil.copy2(path, target / path.name)

(stage / "spike/UPSTREAM_COMMIT.txt").write_text(commit + "\n")
(stage / "spike/changes.patch").write_bytes(patch)

for name in new:
    source = spike / name
    if source.suffix not in (
        ".h", ".cc", ".c", ".inc", ".in", ".S", ".mk"
    ):
        continue
    dest = stage / "spike/new-files" / name
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, dest)

for name in (
    "encoding.h", "riscv.mk.in", "insns/qmac8.h",
    "insns/qrequant8.h", "insns/qrequant8_math.inc"
):
    source = spike / "riscv" / name
    if source.is_file():
        dest = stage / "spike/custom-source/riscv" / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, dest)

with (stage / "docs/excluded-scripts.csv").open("w", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(("path", "syntax_error"))
    writer.writerows(excluded)

scripts = sorted(
    str(p.relative_to(stage))
    for version in versions
    for p in (stage / "workloads" / version / "scripts").rglob("*")
    if p.is_file())
(stage / "docs/SCRIPTS.txt").write_text("\n".join(scripts) + "\n")

tests = sorted(
    str(p.relative_to(stage))
    for p in (stage / "workloads").rglob("*")
    if p.is_file() and "test" in p.name.lower()
    and p.suffix in (".cc", ".cpp", ".c", ".py", ".sh"))
(stage / "tests/INDEX.txt").write_text("\n".join(tests) + "\n")

(stage / ".gitignore").write_text(
    "**/build/\n**/__pycache__/\n*.pyc\n*.o\n*.elf\n*.map\n"
    "**/pc-histogram.txt\n**/disassembly.txt\ntools/\n")

print("PREPARED:", stage)
print("Scripts:", len(scripts), "Test candidates:", len(tests))
print("Excluded scripts with syntax errors:", len(excluded))
print("Review docs/excluded-scripts.csv before submission")
