from pathlib import Path
import re

p = Path("src/conv_block4.inc")
h = Path("src/tensorflow/lite/micro/kernels/internal/reference/integer_ops/conv.h")
u = Path("src/x1_qmac8.h")

s, header, helper = p.read_text(), h.read_text(), u.read_text()
assert "X1_PACKED_CONV" not in s, "X1 already installed"
assert header.count('#include "conv_block4.inc"') == 1
assert "namespace x1" in helper and "Qmac8(" in helper

guard = r"if\s*\(\s*groups\s*==\s*1\s*&&\s*output_depth\s*%\s*8\s*==\s*0\s*\)\s*\{"
assert len(list(re.finditer(guard, s))) == 1, "Expected original block8"

loop = r"for\s*\(\s*int\s+ic\s*=\s*0\s*;\s*ic\s*<\s*input_depth\s*;\s*(?:\+\+ic|ic\+\+)\s*\)\s*\{"
loops = list(re.finditer(loop, s))
assert len(loops) == 1, "Unexpected input-channel loop"

a = loops[0].end()
b, depth = a, 1
while depth:
    assert b < len(s), "Incomplete loop"
    depth += (s[b] == "{") - (s[b] == "}")
    b += 1

body = re.sub(r"\s+", "", s[a:b-1])
expected = []
for pointer in (False, True):
    inp = "*in++" if pointer else "in[ic]"
    text = "constint32_tx=int32_t(" + inp + ")+input_offset;"
    for j in range(8):
        w = f"*w{j}++" if pointer else f"w{j}[ic]"
        text += f"a{j}+=x*int32_t({w});"
    expected.append(text)
assert body in expected, "Inner loop differs; no files changed"

lines = [
    "for (int ic = 0; ic < input_depth; ic += 8) {",
    "  const uint64_t packed = ::x1::Load8(in + ic);"
]
for j in range(8):
    lines.append(
        f"  a{j} = ::x1::Qmac8(a{j}, packed, ::x1::Load8(w{j} + ic));"
    )

lines += [
    "}",
    "if (input_offset != 0) {",
    "  const int tap = fy * filter_width + fx;"
]
for j in range(8):
    lines.append(
        f"  a{j} += x1_correction[(oc + {j}) * x1_taps + tap];"
    )
lines.append("}")

fast = s[:loops[0].start()] + "\n".join(lines) + s[b:]
g = re.search(guard, fast)

init = '''
  const int x1_taps = filter_height * filter_width;
  static int32_t x1_correction[4608];
  if (input_offset != 0) {
    for (int c = 0; c < output_depth; ++c) {
      for (int t = 0; t < x1_taps; ++t) {
        const int8_t* w =
            filter_data + (c * x1_taps + t) * input_depth;
        int32_t sum = 0;
        for (int i = 0; i < input_depth; ++i)
          sum += int32_t(w[i]);
        x1_correction[c * x1_taps + t] = input_offset * sum;
      }
    }
  }
'''
condition = '''if (groups == 1 && output_depth % 8 == 0 &&
    input_depth >= 8 && input_depth % 8 == 0 &&
    int64_t(output_depth) * filter_height * filter_width <= 4608) {'''

fast = fast[:g.start()] + condition + init + fast[g.end():]

include = '#include "x1_qmac8.h"\n'
if include not in header:
    header = include + header

old_load = "  std::memcpy(&value, p, sizeof(value));"
new_load = '''  if ((reinterpret_cast<uintptr_t>(p) & 7u) == 0) {
    std::memcpy(&value, __builtin_assume_aligned(p, 8), sizeof(value));
  } else {
    std::memcpy(&value, p, sizeof(value));
  }'''
assert helper.count(old_load) == 1, "Unexpected Load8 helper"
helper = helper.replace(old_load, new_load, 1)

changes = {
    p: "// X1_PACKED_CONV\n" + fast
       + "\n// Original block8 fallback\n" + s,
    h: header,
    u: helper,
}

for path in changes:
    backup = path.with_name(path.name + ".pre-x1")
    assert not backup.exists(), "Backup exists: " + str(path)

for path, text in changes.items():
    path.with_name(path.name + ".pre-x1").write_bytes(path.read_bytes())
    path.write_text(text)

print("PASS: X1 packed Conv installed; original fallback kept")
print("Correction buffer: 18432 bytes; computed inside Invoke")
