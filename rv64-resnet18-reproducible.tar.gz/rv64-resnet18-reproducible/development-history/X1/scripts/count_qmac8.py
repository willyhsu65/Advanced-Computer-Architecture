from pathlib import Path
from collections import Counter
import json
import re
import sys

args = sys.argv[1:] or [
    "report/disassembly.txt", "report/pc-histogram.txt"
]
assert len(args) == 2
disassembly, histogram = map(Path, args)
custom_pcs = set()

for line in disassembly.read_text().splitlines():
    m = re.match(r"^\s*([0-9a-fA-F]+):\s+(.*)$", line)
    if not m:
        continue
    tokens = m[2].split()
    if not tokens:
        continue
    word = None
    if re.fullmatch(r"[0-9a-fA-F]{8}", tokens[0]):
        word = int(tokens[0], 16)
    elif len(tokens) >= 4 and all(
        re.fullmatch(r"[0-9a-fA-F]{2}", t) for t in tokens[:4]
    ):
        word = int.from_bytes(
            bytes(int(t, 16) for t in tokens[:4]), "little"
        )
    if word is not None and (word & 0xfe00707f) == 0x0b:
        custom_pcs.add(int(m[1], 16))

counts = Counter()
pattern = r"^\s*(?:0x)?([0-9a-fA-F]+)(?:\s*:\s*|\s+)([0-9]+)\s*$"
for line in histogram.read_text().splitlines():
    m = re.match(pattern, line)
    if m:
        counts[int(m[1], 16)] += int(m[2])

total = sum(counts.values())
assert total > 0, "No histogram counts parsed"
dynamic = sum(counts[pc] for pc in custom_pcs)
fraction = dynamic / total

data = {
    "scope": "supplied_pc_histogram",
    "histogram_dynamic_instructions": total,
    "qmac8_static_instructions": len(custom_pcs),
    "qmac8_dynamic_instructions": dynamic,
    "qmac8_fraction": fraction,
    "qmac8_executed_macs": dynamic * 8,
}
table = (
    "Scope: supplied PC histogram.\n\n"
    "| Metric | Value |\n|---|---:|\n"
    f"| Histogram instructions | {total:,} |\n"
    f"| QMAC8 static instructions | {len(custom_pcs):,} |\n"
    f"| QMAC8 dynamic instructions | {dynamic:,} |\n"
    f"| QMAC8 / histogram instructions | {fraction:.4%} |\n"
    f"| MACs executed by QMAC8 | {dynamic * 8:,} |\n"
)
(histogram.parent / "qmac8_metrics.json").write_text(
    json.dumps(data, indent=2) + "\n"
)
(histogram.parent / "qmac8_metrics.md").write_text(table)
print(table)
