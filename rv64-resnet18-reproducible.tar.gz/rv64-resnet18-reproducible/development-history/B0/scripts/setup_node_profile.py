from pathlib import Path
import re
import sys

root = Path(sys.argv[1]).resolve()
assert (root / "Makefile").is_file(), "Missing Makefile: " + str(root)
s = (root / "src/main.cc").read_text()
assert s.count("CheckProfiler profiler;") == 1, "Unsupported profiler declaration"
s = s.replace("CheckProfiler profiler;", "static NodeProfiler profiler;")

replacement = """InspectableInterpreter interpreter(
      model, resolver, arena, sizeof(arena), nullptr, &profiler);"""
pattern = (
    r"#ifdef BENCHMARK\s+InspectableInterpreter interpreter\("
    r".*?#else\s+InspectableInterpreter interpreter\(.*?#endif")
s, n = re.subn(pattern, replacement, s, count=1, flags=re.S)

if not n:
    pattern = (
        r"InspectableInterpreter interpreter\(\s*model\s*,\s*resolver\s*,"
        r"\s*arena\s*,\s*sizeof\(arena\)\s*"
        r"(?:,\s*nullptr\s*,\s*&profiler\s*)?\);")
    s, n = re.subn(pattern, replacement, s)
assert n == 1, "Unsupported interpreter constructor"
s = s.replace("profiler.interpreter = &interpreter;", "")

pattern = (
    r'platform_log\(\s*"Per-operator checks:[\s\S]*?'
    r'profiler\.failures\s*\);\s*'
    r'if\s*\(\s*profiler\.events\s*!=\s*kOpCount\s*\|\|\s*'
    r'profiler\.failures\s*\)\s*\{\s*return 7;\s*\}')
s = re.sub(pattern, "", s)
body = s[s.index("int main()"):]
assert "profiler.events" not in body, "Unsupported old event checks"
assert "profiler.failures" not in body, "Unsupported old failure checks"

call = "const auto result = interpreter.Invoke();"
assert s.count(call) == 1, "Unsupported Invoke"
s = s.replace(call, """profiler.Reset();
  const uint64_t node_start = NodeProfiler::Read();
  const auto result = interpreter.Invoke();
  const uint64_t node_end = NodeProfiler::Read();""")

tail = s.rfind("  return 0;")
assert tail != -1
s = s[:tail] + """  if (!profiler.Dump(node_end - node_start,
      model->subgraphs()->Get(0)->operators()->size())) return 12;
""" + s[tail:]
s = """#ifndef BENCHMARK
#define BENCHMARK 1
#endif
#include "node_profiler.h"
""" + s

dest = root / "src/main_node_profile.cc"
assert not dest.exists() or dest.read_text() == s, (
    "Existing measurement main differs: " + str(dest))
dest.write_text(s)
print("READY:", root.name, flush=True)
