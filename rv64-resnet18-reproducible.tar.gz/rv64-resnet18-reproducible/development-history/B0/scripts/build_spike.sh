#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
project="${ACA_PROJECT:-$(cd ../.. && pwd)}"
export RISCV_PREFIX="${RISCV_PREFIX:-$project/tools/xpack-riscv-none-embed-gcc-10.2.0-1.2/bin/riscv-none-embed-}"
python_bin="${PYTHON:-python3}"
if [[ -x "$project/tools/model-env/bin/python" && -z "${PYTHON:-}" ]]; then
  python_bin="$project/tools/model-env/bin/python"
fi
sha256sum -c models/SHA256SUMS
printf 'Building RV64IMC executable...\n'
make -j"${JOBS:-4}" MODE=frozen spike > build-spike.log 2>&1 || { tail -60 build-spike.log; exit 1; }
"$python_bin" scripts/audit_elf.py "$RISCV_PREFIX" build/rv64-frozen/resnet18_tflm.elf | tee audit.log
printf 'ELF: build/rv64-frozen/resnet18_tflm.elf\n'
