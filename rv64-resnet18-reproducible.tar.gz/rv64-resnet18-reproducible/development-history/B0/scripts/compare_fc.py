#!/usr/bin/env python3
"""Host-only explanation of the LiteRT versus TFLM final-layer difference."""
import json
import re
from pathlib import Path
import numpy as np
from ai_edge_litert.interpreter import Interpreter, OpResolverType

r=Path(__file__).resolve().parents[1]
i=Interpreter(model_path=str(r/'models/resnet18_int8_channelwise.tflite'),
    experimental_op_resolver_type=OpResolverType.BUILTIN_REF,
    experimental_preserve_all_tensors=True,num_threads=1)
i.allocate_tensors()
i.set_tensor(85,np.fromfile(r/'reference/input_i8.bin',dtype=np.int8).reshape(1,3,224,224))
i.invoke()
x=i.get_tensor(82).astype(np.int64).reshape(-1)
w=i.get_tensor(45).astype(np.int64)
b=i.get_tensor(44).astype(np.int64)
acc=w@(x+128)+b
details={d['index']:d for d in i.get_tensor_details()}
scales=details[45]['quantization_parameters']['scales'].astype(np.float64)
sx=float(details[82]['quantization_parameters']['scales'][0])
sy=float(details[41]['quantization_parameters']['scales'][0])
v=acc.astype(np.float64)*(sx*scales/sy)
floating=np.clip(np.where(v<0,np.ceil(v-0.5),np.floor(v+0.5))-61,-128,127).astype(np.int8)
text=(r/'generated/frozen_data.h').read_text()
def array(name):
    return [int(v) for v in re.search(r'constexpr int32_t '+name+r'\[\] = \{([^}]+)\}',text).group(1).split(',')]
mult,shift=array('m36'),array('s36')
def requant(a,m,s):
    a=int(a)*(1<<max(s,0)); ab=a*m
    nudge=(1<<30) if ab>=0 else 1-(1<<30)
    num=ab+nudge
    h=abs(num)//(1<<31)*(1 if num>=0 else -1)
    n=max(-s,0); mask=(1<<n)-1
    result=(h>>n)+int((h&mask)>((mask>>1)+int(h<0)))
    return max(-128,min(127,result-61))
integer=np.array([requant(a,m,s) for a,m,s in zip(acc,mult,shift)],dtype=np.int8)
litert=np.fromfile(r/'reference/output_i8.bin',dtype=np.int8)
tflm=np.fromfile(r/'reference/tflm_output_i8.bin',dtype=np.int8)
assert np.array_equal(floating,litert), 'Float requant formula does not reproduce LiteRT'
assert np.array_equal(integer,tflm), 'Integer requant formula does not reproduce TFLM'
idx=np.where(litert!=tflm)[0]
report={'float_requant_matches_litert':True,'integer_requant_matches_tflm':True,
    'differences':[{'index':int(k),'litert':int(litert[k]),'tflm':int(tflm[k])} for k in idx],
    'max_absolute_difference':int(np.max(np.abs(litert.astype(int)-tflm.astype(int))))}
(r/'reference/fc_comparison.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
