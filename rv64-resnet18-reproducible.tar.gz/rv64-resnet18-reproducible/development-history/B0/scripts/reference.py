#!/usr/bin/env python3
"""Host-only reference generator; never runs on Spike."""
import hashlib
import json
from pathlib import Path
import flatbuffers
import numpy as np
from ai_edge_litert import schema_py_generated as s
from ai_edge_litert.interpreter import Interpreter, OpResolverType

root = Path(__file__).resolve().parents[1]
raw = (root / 'models/resnet18_int8_channelwise.tflite').read_bytes()
assert hashlib.sha256(raw).hexdigest() == '8fea1acb62829e120b4953b6fbf0f842e0032909254f51c2d989703b66534683'
model = s.ModelT.InitFromObj(s.Model.GetRootAsModel(raw, 0))
g = model.subgraphs[0]
assert len(model.subgraphs) == 1 and len(g.operators) == 37
assert all(t.type in (s.TensorType.INT8, s.TensorType.INT32) for t in g.tensors)
# Mark intermediate outputs as graph outputs in a REFERENCE-ONLY copy. This
# prevents in-place ADD from destroying values before get_tensor() reads them.
outputs = list(g.outputs)
for op in g.operators:
    for idx in op.outputs:
        if int(idx) not in outputs:
            outputs.append(int(idx))
g.outputs = outputs
b = flatbuffers.Builder(len(raw) + 65536)
b.Finish(model.Pack(b), file_identifier=b'TFL3')
interpreter = Interpreter(model_content=bytes(b.Output()), num_threads=1,
    experimental_op_resolver_type=OpResolverType.BUILTIN_REF,
    experimental_preserve_all_tensors=True)
interpreter.allocate_tensors()
x = np.random.default_rng(0).integers(-128, 128, size=(1, 3, 224, 224), dtype=np.int8)
interpreter.set_tensor(int(g.inputs[0]), x)
interpreter.invoke()
y = interpreter.get_tensor(int(g.outputs[0]))
(root / 'reference/input_i8.bin').write_bytes(x.tobytes())
(root / 'reference/output_i8.bin').write_bytes(y.tobytes())
rows = []
for op in g.operators:
    idx = int(op.outputs[0])
    data = interpreter.get_tensor(idx).tobytes()
    h = 14695981039346656037
    for v in data:
        h = ((h ^ v) * 1099511628211) & ((1 << 64) - 1)
    rows.append((idx, len(data), h))
header = '#pragma once\n#include <cstddef>\n#include <cstdint>\n'
header += f'constexpr size_t kInputBytes = {x.nbytes};\nconstexpr size_t kOutputBytes = {y.nbytes};\n'
header += 'struct OpReference { int tensor; size_t bytes; uint64_t hash; };\n'
header += 'constexpr OpReference kOpReference[] = {\n'
header += ''.join(f'  {{{i}, {n}, UINT64_C(0x{h:016x})}},\n' for i, n, h in rows)
header += '};\nconstexpr unsigned kOpCount = sizeof(kOpReference)/sizeof(kOpReference[0]);\n'
(root / 'generated/reference.h').write_text(header)
manifest = {'model_sha256': hashlib.sha256(raw).hexdigest(), 'reference_runtime': 'ai-edge-litert 2.3.0 BUILTIN_REF',
    'seed': 0, 'top1_index': int(y.argmax()), 'output_min': int(y.min()), 'output_max': int(y.max()),
    'operators': [{'output_tensor': i, 'bytes': n, 'fnv1a64': f'{h:016x}'} for i, n, h in rows]}
(root / 'reference/manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print('Reference generated:', len(rows), 'ops; Top-1:', y.argmax())
