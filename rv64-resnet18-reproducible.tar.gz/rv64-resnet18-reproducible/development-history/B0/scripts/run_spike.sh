#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
project="${ACA_PROJECT:-$(cd ../.. && pwd)}"
spike_bin="${SPIKE:-$project/tools/spike-install/bin/spike}"
help_text="$("$spike_bin" --help 2>&1)"
args=(--isa=RV64IMC --disable-dtb -m128)
runner=(env)
# Older Spike omits its reset ROM with --disable-dtb. It requires dtc instead.
if [[ "$help_text" == *"Simulator 1.1.0"* || "$help_text" == *"Simulator 1.0"* ]]; then
  args=(--isa=RV64IMC -m128)
  if ! command -v dtc >/dev/null && [[ -x "$project/tools/bin/micromamba" && -d "$project/tools/spike-build-env" ]]; then
    runner=("$project/tools/bin/micromamba" run -p "$project/tools/spike-build-env")
  fi
fi
"${runner[@]}" "$spike_bin" "${args[@]}" build/rv64-frozen/resnet18_tflm.elf 2>&1 | tee spike.log
