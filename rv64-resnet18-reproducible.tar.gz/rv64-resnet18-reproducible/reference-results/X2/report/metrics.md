| 指標                           | 數值          | 說明                                              |
| ------------------------------ | ------------- | ------------------------------------------------- |
| 1. 動態指令數                  | 4,493,103,841 | whole_program / histogram                         |
| 1. Retired 指令數              | 尚未量測      | 與 histogram 相同區間                             |
| 2. Load                        | 1,523,587,300 | 33.909%                                           |
| 2. Store                       | 969,154,553   | 21.570%                                           |
| 2. Integer ALU                 | 1,307,209,953 | 29.094%                                           |
| 2. Multiply                    | 126,299,087   | 2.811%                                            |
| 2. Branch / jump               | 367,727,660   | 8.184%                                            |
| 2. Custom                      | 199,124,480   | 4.432%                                            |
| 2. Other                       | 802           | 0.000%                                            |
| 2. Unmapped                    | 6             | 0.000%                                            |
| 3. Memory 指令數               | 2,492,741,853 | 已知 load + store；仍有未分類指令                 |
| 4. 模型 MAC 數                 | 1,814,073,344 | Dense Conv/FC MACs / inference                    |
| 4. MAC / retired               | 0.404519      | 分母：一次 Invoke 的 retired 指令數               |
| 5. Operator 貢獻               | 尚未量測      | 需要逐層 retired counter                          |
| 6. Code size                   | 34,770 bytes  | 可執行 section，不含模型權重與 BSS                |
| 7. Custom 指令數               | 199,124,480   | 依指定的 mnemonic 或 encoding 統計                |
| 7. Custom / histogram          | 4.432%        | 占 histogram 總指令數                             |
| 7. Custom / retired            | 尚未量測      | 分母須為相同量測區間                              |
| 8. Requant helper instructions | 28,044        | whole_program; self only                          |
| 8. Requant helper / histogram  | 0.001%        | Same-scope histogram; instruction share, not time |

Operator 比例是指令占比；不代表執行時間。


| Custom instruction | Dynamic count | Histogram share |
|---|---:|---:|
| qmac8 | 196,640,768 | 4.3765% |
| qrequant8 | 2,483,712 | 0.0553% |
