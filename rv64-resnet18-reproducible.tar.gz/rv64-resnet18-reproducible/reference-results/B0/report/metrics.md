| 指標                  | 數值           | 說明                                |
| --------------------- | -------------- | ----------------------------------- |
| 1. 動態指令數         | 22,171,572,199 | whole_program / histogram           |
| 1. Retired 指令數     | 尚未量測       | 與 histogram 相同區間               |
| 2. Load               | 8,964,651,436  | 40.433%                             |
| 2. Store              | 1,756,454,226  | 7.922%                              |
| 2. Integer ALU        | 7,617,573,711  | 34.357%                             |
| 2. Multiply           | 1,731,104,395  | 7.808%                              |
| 2. Branch / jump      | 2,099,303,911  | 9.468%                              |
| 2. Custom             | 0              | 0.000%                              |
| 2. Other              | 2,484,514      | 0.011%                              |
| 2. Unmapped           | 6              | 0.000%                              |
| 3. Memory 指令數      | 10,721,105,662 | 已知 load + store；仍有未分類指令   |
| 4. 模型 MAC 數        | 1,814,073,344  | Dense Conv/FC MACs / inference      |
| 4. MAC / retired      | 0.081851       | 分母：一次 Invoke 的 retired 指令數 |
| 5. Operator 貢獻      | 尚未量測       | 需要逐層 retired counter            |
| 6. Code size          | 59,294 bytes   | 可執行 section，不含模型權重與 BSS  |
| 7. Custom 指令數      | 不適用／未設定 | 依指定的 mnemonic 或 encoding 統計  |
| 7. Custom / histogram | —              | 占 histogram 總指令數               |
| 7. Custom / retired   | —              | 分母須為相同量測區間                |

Operator 比例是指令占比；不代表執行時間。
