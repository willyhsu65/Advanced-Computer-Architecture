| 指標                           | 數值           | 說明                                              |
| ------------------------------ | -------------- | ------------------------------------------------- |
| 1. 動態指令數                  | 9,732,485,802  | whole_program / histogram                         |
| 1. Retired 指令數              | 尚未量測       | 與 histogram 相同區間                             |
| 2. Load                        | 2,684,035,209  | 27.578%                                           |
| 2. Store                       | 75,215,035     | 0.773%                                            |
| 2. Integer ALU                 | 4,960,667,784  | 50.970%                                           |
| 2. Multiply                    | 1,700,989,507  | 17.477%                                           |
| 2. Branch / jump               | 311,577,459    | 3.201%                                            |
| 2. Custom                      | 0              | 0.000%                                            |
| 2. Other                       | 802            | 0.000%                                            |
| 2. Unmapped                    | 6              | 0.000%                                            |
| 3. Memory 指令數               | 2,759,250,244  | 已知 load + store；仍有未分類指令                 |
| 4. 模型 MAC 數                 | 1,814,073,344  | Dense Conv/FC MACs / inference                    |
| 4. MAC / retired               | 0.186558       | 分母：一次 Invoke 的 retired 指令數               |
| 5. Operator 貢獻               | 尚未量測       | 需要逐層 retired counter                          |
| 6. Code size                   | 32,440 bytes   | 可執行 section，不含模型權重與 BSS                |
| 7. Custom 指令數               | 不適用／未設定 | 依指定的 mnemonic 或 encoding 統計                |
| 7. Custom / histogram          | —              | 占 histogram 總指令數                             |
| 7. Custom / retired            | —              | 分母須為相同量測區間                              |
| 8. Requant helper instructions | 69,967,592     | whole_program; self only                          |
| 8. Requant helper / histogram  | 0.719%         | Same-scope histogram; instruction share, not time |

Operator 比例是指令占比；不代表執行時間。
