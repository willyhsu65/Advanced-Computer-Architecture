| 指標                           | 數值          | 說明                                              |
| ------------------------------ | ------------- | ------------------------------------------------- |
| 1. 動態指令數                  | 4,460,339,654 | whole_program / histogram                         |
| 1. Retired 指令數              | 尚未量測      | 與 histogram 相同區間                             |
| 2. Load                        | 1,463,723,381 | 32.816%                                           |
| 2. Store                       | 915,459,493   | 20.524%                                           |
| 2. Integer ALU                 | 1,371,778,713 | 30.755%                                           |
| 2. Multiply                    | 128,782,799   | 2.887%                                            |
| 2. Branch / jump               | 383,953,692   | 8.608%                                            |
| 2. Custom                      | 196,640,768   | 4.409%                                            |
| 2. Other                       | 802           | 0.000%                                            |
| 2. Unmapped                    | 6             | 0.000%                                            |
| 3. Memory 指令數               | 2,379,182,874 | 已知 load + store；仍有未分類指令                 |
| 4. 模型 MAC 數                 | 1,814,073,344 | Dense Conv/FC MACs / inference                    |
| 4. MAC / retired               | 0.407496      | 分母：一次 Invoke 的 retired 指令數               |
| 5. Operator 貢獻               | 尚未量測      | 需要逐層 retired counter                          |
| 6. Code size                   | 34,462 bytes  | 可執行 section，不含模型權重與 BSS                |
| 7. Custom 指令數               | 196,640,768   | 依指定的 mnemonic 或 encoding 統計                |
| 7. Custom / histogram          | 4.409%        | 占 histogram 總指令數                             |
| 7. Custom / retired            | 尚未量測      | 分母須為相同量測區間                              |
| 8. Requant helper instructions | 69,967,592    | whole_program; self only                          |
| 8. Requant helper / histogram  | 1.569%        | Same-scope histogram; instruction share, not time |

Operator 比例是指令占比；不代表執行時間。


| Custom instruction | Dynamic count | Histogram share |
|---|---:|---:|
| qmac8 | 196,640,768 | 4.4087% |
