Scope: supplied PC histogram.

| Metric | Value |
|---|---:|
| Histogram instructions | 4,460,339,654 |
| QMAC8 static instructions | 15 |
| QMAC8 dynamic instructions | 196,640,768 |
| QMAC8 / histogram instructions | 4.4087% |
| MACs executed by QMAC8 | 1,573,126,144 |
