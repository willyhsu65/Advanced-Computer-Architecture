#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [[ ! -f "$root/tools/bootstrap.json" ]]; then
    python3 "$root/scripts/bootstrap.py" --jobs "${JOBS:-4}"
fi
if [[ "$#" -eq 0 ]]; then
    set -- verify
fi
exec python3 "$root/scripts/reproduce.py" "$@"
